# Firebase Storage Setup Guide

## 🚀 Adding Firebase Storage to Your Project

Your app currently has a fallback implementation for Firebase Storage. To enable full Firebase Storage functionality, follow these steps:

## 📋 Prerequisites

1. **Firebase Project** - You should already have a Firebase project set up
2. **Firebase Core** - Firebase Core should already be configured
3. **Xcode Project** - Your iOS project should be ready

## 🔧 Installation Methods

### Method 1: Swift Package Manager (Recommended)

1. **Open Xcode** and navigate to your project
2. **File → Add Package Dependencies**
3. **Enter URL:** `https://github.com/firebase/firebase-ios-sdk`
4. **Select FirebaseStorage** from the available packages
5. **Click Add Package**

### Method 2: CocoaPods

1. **Add to Podfile:**
```ruby
pod 'Firebase/Storage'
```

2. **Run in Terminal:**
```bash
pod install
```

3. **Open .xcworkspace file** (not .xcodeproj)

### Method 3: Manual Installation

1. **Download Firebase iOS SDK** from [Firebase Console](https://console.firebase.google.com/)
2. **Extract the downloaded file**
3. **Drag FirebaseStorage.framework** to your Xcode project
4. **Add to Target Dependencies**

## ⚙️ Configuration

### 1. Update FirebaseStorageService.swift

After adding FirebaseStorage, update your `FirebaseStorageService.swift`:

```swift
import Foundation
import UIKit
import FirebaseStorage // Uncomment this line

// MARK: - Firebase Storage Service
class FirebaseStorageService: ObservableObject {
    static let shared = FirebaseStorageService()
    
    private let storage = Storage.storage() // Uncomment this line
    
    private init() {}
    
    // MARK: - Profile Image Upload
    func uploadProfileImage(_ image: UIImage, userId: String) async throws -> String {
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            throw NSError(domain: "FirebaseStorageService", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to compress image"])
        }
        
        let storageRef = storage.reference().child("profile_images/\(userId).jpg")
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpeg"
        
        _ = try await storageRef.putDataAsync(imageData, metadata: metadata)
        return try await storageRef.downloadURL().absoluteString
    }
    
    // ... rest of your methods
}
```

### 2. Firebase Console Configuration

1. **Go to Firebase Console** → Your Project → Storage
2. **Get Started** → Create a bucket
3. **Choose location** for your storage bucket
4. **Set security rules:**

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Allow authenticated users to upload profile images
    match /profile_images/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Allow authenticated users to upload chat images
    match /chat_images/{chatId}/{messageId} {
      allow read, write: if request.auth != null;
    }
    
    // Allow authenticated users to upload files
    match /{folder}/{fileName} {
      allow read, write: if request.auth != null;
    }
  }
}
```

### 3. Update AppDelegate

Make sure Firebase is configured in your `AppDelegate`:

```swift
import Firebase
import FirebaseStorage

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication,
                    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        // Configure Firebase
        FirebaseApp.configure()
        
        return true
    }
}
```

## 🧪 Testing Firebase Storage

### 1. Test Profile Image Upload

```swift
// Test in your app
let testImage = UIImage(systemName: "person.circle.fill")!
let userId = "test_user_123"

Task {
    do {
        let imageURL = try await FirebaseStorageService.shared.uploadProfileImage(testImage, userId: userId)
        print("Image uploaded successfully: \(imageURL)")
    } catch {
        print("Upload failed: \(error)")
    }
}
```

### 2. Test File Upload

```swift
// Test file upload
let testData = "Hello, Firebase Storage!".data(using: .utf8)!

Task {
    do {
        let fileURL = try await FirebaseStorageService.shared.uploadFile(testData, fileName: "test.txt", folder: "documents")
        print("File uploaded successfully: \(fileURL)")
    } catch {
        print("Upload failed: \(error)")
    }
}
```

## 🔒 Security Rules

### Production Security Rules

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Profile images - users can only access their own
    match /profile_images/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Chat images - authenticated users can read/write
    match /chat_images/{chatId}/{messageId} {
      allow read, write: if request.auth != null;
    }
    
    // General files - authenticated users only
    match /{folder}/{fileName} {
      allow read, write: if request.auth != null;
    }
    
    // Deny all other access
    match /{allPaths=**} {
      allow read, write: if false;
    }
  }
}
```

## 📊 Storage Usage Monitoring

### 1. Firebase Console
- Monitor storage usage in Firebase Console
- Set up alerts for storage limits
- View upload/download statistics

### 2. Code Monitoring

```swift
// Monitor upload progress
func uploadWithProgress(_ image: UIImage, userId: String) async throws -> String {
    guard let imageData = image.jpegData(compressionQuality: 0.8) else {
        throw NSError(domain: "FirebaseStorageService", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to compress image"])
    }
    
    let storageRef = storage.reference().child("profile_images/\(userId).jpg")
    let metadata = StorageMetadata()
    metadata.contentType = "image/jpeg"
    
    let uploadTask = storageRef.putData(imageData, metadata: metadata)
    
    // Monitor upload progress
    uploadTask.observe(.progress) { snapshot in
        let percentComplete = 100.0 * Double(snapshot.progress!.completedUnitCount) / Double(snapshot.progress!.totalUnitCount)
        print("Upload progress: \(percentComplete)%")
    }
    
    _ = try await uploadTask
    return try await storageRef.downloadURL().absoluteString
}
```

## 🚨 Troubleshooting

### Common Issues

#### 1. "No such module 'FirebaseStorage'"
**Solution:**
- Ensure FirebaseStorage is properly added to your project
- Clean and rebuild your project
- Check that the framework is added to your target

#### 2. "Permission denied" errors
**Solution:**
- Check Firebase Storage security rules
- Ensure user is authenticated
- Verify user has proper permissions

#### 3. Upload failures
**Solution:**
- Check network connectivity
- Verify Firebase project configuration
- Check storage bucket permissions

#### 4. Large file uploads failing
**Solution:**
- Implement chunked uploads for large files
- Add retry logic for failed uploads
- Monitor upload progress

## 📱 Production Considerations

### 1. File Size Limits
- Set appropriate file size limits
- Compress images before upload
- Implement progress indicators

### 2. Error Handling
- Implement comprehensive error handling
- Add retry logic for failed uploads
- Provide user feedback for upload status

### 3. Performance
- Use appropriate image compression
- Implement caching for downloaded images
- Monitor storage usage and costs

### 4. Security
- Implement proper security rules
- Validate file types and sizes
- Use authentication for all uploads

## 🎯 Next Steps

1. **Add FirebaseStorage** to your project using one of the methods above
2. **Update FirebaseStorageService.swift** to uncomment the Firebase code
3. **Configure Firebase Console** with proper security rules
4. **Test the implementation** with the provided test code
5. **Deploy to production** with proper monitoring

## 📚 Additional Resources

- [Firebase Storage Documentation](https://firebase.google.com/docs/storage)
- [Firebase iOS SDK](https://github.com/firebase/firebase-ios-sdk)
- [Storage Security Rules](https://firebase.google.com/docs/storage/security)
- [Upload Files](https://firebase.google.com/docs/storage/ios/upload-files)
- [Download Files](https://firebase.google.com/docs/storage/ios/download-files)

---

## ✅ Current Status

- ✅ Fallback implementation working
- ⏳ FirebaseStorage module needs to be added
- ⏳ Production configuration pending
- ⏳ Security rules need to be set up

Once you add FirebaseStorage to your project, your app will have full file upload and storage capabilities! 🚀
