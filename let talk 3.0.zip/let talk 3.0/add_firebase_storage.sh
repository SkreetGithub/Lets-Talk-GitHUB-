#!/bin/bash

# Firebase Storage Setup Script for Let Talk 3.0
# This script helps you add Firebase Storage to your iOS project

echo "🚀 Firebase Storage Setup for Let Talk 3.0"
echo "=========================================="

# Check if we're in the right directory
if [ ! -f "let talk 3.0.xcodeproj/project.pbxproj" ]; then
    echo "❌ Error: Please run this script from the project root directory"
    echo "   Expected to find: let talk 3.0.xcodeproj/project.pbxproj"
    exit 1
fi

echo "✅ Found Xcode project"

# Method 1: Swift Package Manager (Recommended)
echo ""
echo "📦 Method 1: Swift Package Manager (Recommended)"
echo "1. Open Xcode"
echo "2. Go to File → Add Package Dependencies"
echo "3. Enter URL: https://github.com/firebase/firebase-ios-sdk"
echo "4. Select 'FirebaseStorage' from the list"
echo "5. Click 'Add Package'"
echo ""

# Method 2: CocoaPods
echo "📦 Method 2: CocoaPods"
echo "1. Add to your Podfile:"
echo "   pod 'Firebase/Storage'"
echo "2. Run: pod install"
echo "3. Open .xcworkspace file (not .xcodeproj)"
echo ""

# Method 3: Manual
echo "📦 Method 3: Manual Installation"
echo "1. Download Firebase iOS SDK from Firebase Console"
echo "2. Extract and drag FirebaseStorage.framework to your project"
echo "3. Add to Target Dependencies"
echo ""

echo "🔧 After adding FirebaseStorage:"
echo "1. Update FirebaseStorageService.swift:"
echo "   - Uncomment 'import FirebaseStorage'"
echo "   - Uncomment 'private let storage = Storage.storage()'"
echo "   - Uncomment all the Firebase code in methods"
echo ""

echo "2. Configure Firebase Console:"
echo "   - Go to Storage → Get Started"
echo "   - Create a bucket"
echo "   - Set up security rules"
echo ""

echo "3. Test the implementation:"
echo "   - Run the app"
echo "   - Try uploading a profile image"
echo "   - Check Firebase Console for uploaded files"
echo ""

echo "📚 For detailed instructions, see: FIREBASE_STORAGE_SETUP_GUIDE.md"
echo ""
echo "🎉 Your app is ready for Firebase Storage!"
