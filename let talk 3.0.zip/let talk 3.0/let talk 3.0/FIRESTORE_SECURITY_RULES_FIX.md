# Firestore Security Rules Fix

## Issue
The app is getting "Missing or insufficient permissions" errors when trying to access the chats collection in Firestore.

## Solution
You need to update your Firestore security rules to allow authenticated users to read and write to the chats collection.

## Steps to Fix

### 1. Go to Firebase Console
1. Open [Firebase Console](https://console.firebase.google.com/)
2. Select your project: `lets-talk-b777f`
3. Navigate to **Firestore Database** in the left sidebar
4. Click on the **Rules** tab

### 2. Update Security Rules
Replace your current rules with the following:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read/write their own user document
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Users can read/write their own contacts
    match /users/{userId}/contacts/{contactId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Users can read/write chats they participate in
    match /chats/{chatId} {
      allow read, write: if request.auth != null && 
        (resource.data.participants[request.auth.uid] == true || 
         request.auth.uid in resource.data.participants);
    }
    
    // Users can read/write messages in chats they participate in
    match /chats/{chatId}/messages/{messageId} {
      allow read, write: if request.auth != null && 
        (get(/databases/$(database)/documents/chats/$(chatId)).data.participants[request.auth.uid] == true ||
         request.auth.uid in get(/databases/$(database)/documents/chats/$(chatId)).data.participants);
    }
    
    // Users can read/write their own calls
    match /calls/{callId} {
      allow read, write: if request.auth != null && 
        (resource.data.participants[request.auth.uid] == true ||
         request.auth.uid in resource.data.participants);
    }
    
    // Users can read/write their own translation history
    match /users/{userId}/translations/{translationId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Allow demo mode access (for testing without authentication)
    match /demo/{document=**} {
      allow read, write: if true;
    }
  }
}
```

### 3. Publish Rules
1. Click **Publish** to save the new rules
2. Wait for the rules to be deployed (usually takes a few seconds)

### 4. Test the Rules
The rules above will:
- Allow authenticated users to access their own data
- Allow users to participate in chats they're members of
- Allow demo mode access for testing
- Prevent unauthorized access to other users' data

## Alternative: Temporary Open Rules (Development Only)
If you want to test quickly during development, you can temporarily use these open rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

**⚠️ WARNING: Never use open rules in production! This allows anyone to read/write your entire database.**

## Verification
After updating the rules, your app should no longer show "Missing or insufficient permissions" errors when accessing Firestore collections.

## Additional Notes
- Make sure your app is properly authenticated before accessing Firestore
- The rules assume your chat documents have a `participants` field with user IDs
- Adjust the rules based on your specific data structure if needed
