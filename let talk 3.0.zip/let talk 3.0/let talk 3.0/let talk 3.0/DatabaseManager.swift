import Foundation
import Combine
import FirebaseFirestore
import FirebaseAuth

class DatabaseManager: ObservableObject {
    static let shared = DatabaseManager()
    
    private let db = Firestore.firestore()
    private var listeners: [String: ListenerRegistration] = [:]
    
    // MARK: - Messages
    func sendMessage(_ message: Message) async throws {
        // Check if user is authenticated
        guard Auth.auth().currentUser != nil else {
            throw NSError(domain: "DatabaseManager", code: 401, userInfo: [NSLocalizedDescriptionKey: "User not authenticated"])
        }
        
        let chatId = getChatId(senderId: message.senderId, receiverId: message.receiverId)
        
        // Create message data with chatId
        var messageData: [String: Any] = [
            "id": message.id,
            "senderId": message.senderId,
            "receiverId": message.receiverId,
            "content": message.content,
            "timestamp": Timestamp(date: message.timestamp),
            "type": message.type.rawValue,
            "status": message.status.rawValue,
            "isEncrypted": message.isEncrypted,
            "chatId": chatId
        ]
        
        // Add optional fields if they exist
        if let translation = message.translation {
            messageData["translation"] = translation
        }
        
        if let attachments = message.attachments {
            let attachmentData = attachments.map { attachment in
                [
                    "id": attachment.id,
                    "type": attachment.type.rawValue,
                    "url": attachment.url,
                    "name": attachment.name,
                    "size": attachment.size
                ]
            }
            messageData["attachments"] = attachmentData
        }
        
        if let metadata = message.metadata {
            messageData["metadata"] = metadata
        }
        
        print("Sending message to chat: \(chatId), content: \(message.content)")
        
        do {
            try await db.collection("messages").document(message.id).setData(messageData)
            print("Successfully sent message: \(message.id)")
            
            // Update last message in chat
            try await updateLastMessage(chatId: chatId, message: message)
        } catch {
            print("Error sending message: \(error)")
            throw error
        }
    }
    
    func listenForMessages(in chatId: String) -> AnyPublisher<[Message], Error> {
        let subject = PassthroughSubject<[Message], Error>()
        
        let listener = db.collection("messages")
            .whereField("chatId", isEqualTo: chatId)
            .order(by: "timestamp", descending: true)
            .limit(to: 50)
            .addSnapshotListener { snapshot, error in
                if let error = error {
                    subject.send(completion: .failure(error))
                    return
                }
                
                guard let documents = snapshot?.documents else {
                    subject.send([])
                    return
                }
                
                do {
                    let messages = try documents.compactMap { document -> Message? in
                        let data = document.data()
                        
                        // Convert Firestore data to Message object manually
                        let id = data["id"] as? String ?? document.documentID
                        let senderId = data["senderId"] as? String ?? ""
                        let receiverId = data["receiverId"] as? String ?? ""
                        let content = data["content"] as? String ?? ""
                        let timestamp = (data["timestamp"] as? Timestamp)?.dateValue() ?? Date()
                        let typeString = data["type"] as? String ?? "text"
                        let type = Message.MessageType(rawValue: typeString) ?? .text
                        let statusString = data["status"] as? String ?? "sent"
                        let status = Message.MessageStatus(rawValue: statusString) ?? .sent
                        let isEncrypted = data["isEncrypted"] as? Bool ?? true
                        let translation = data["translation"] as? String
                        let metadata = data["metadata"] as? [String: String]
                        
                        // Handle attachments if they exist
                        var attachments: [Message.Attachment]?
                        if let attachmentsData = data["attachments"] as? [[String: Any]] {
                            attachments = attachmentsData.compactMap { attachmentData in
                                guard let attachmentId = attachmentData["id"] as? String,
                                      let url = attachmentData["url"] as? String,
                                      let typeString = attachmentData["type"] as? String,
                                      let type = Message.Attachment.AttachmentType(rawValue: typeString),
                                      let name = attachmentData["name"] as? String,
                                      let size = attachmentData["size"] as? Int else {
                                    return nil
                                }
                                
                                return Message.Attachment(
                                    id: attachmentId,
                                    url: url,
                                    type: type,
                                    size: size,
                                    name: name,
                                    localPath: attachmentData["localPath"] as? String,
                                    thumbnailUrl: attachmentData["thumbnailUrl"] as? String
                                )
                            }
                        }
                        
                        var message = Message(
                            id: id,
                            senderId: senderId,
                            receiverId: receiverId,
                            content: content,
                            type: type,
                            attachments: attachments,
                            timestamp: timestamp,
                            status: status,
                            isEncrypted: isEncrypted
                        )
                        
                        // Set optional fields
                        message.translation = translation
                        message.metadata = metadata
                        
                        return message
                    }
                    subject.send(messages)
                } catch {
                    print("Error parsing messages: \(error)")
                    subject.send(completion: .failure(error))
                }
            }
        
        listeners[chatId] = listener
        return subject.eraseToAnyPublisher()
    }
    
    // MARK: - Chats
    func createOrUpdateChat(senderId: String, receiverId: String) async throws -> Chat {
        // Validate input parameters
        guard !senderId.isEmpty, !receiverId.isEmpty else {
            throw NSError(domain: "DatabaseManager", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid sender or receiver ID"])
        }
        
        // Check if user is authenticated
        guard Auth.auth().currentUser != nil else {
            throw NSError(domain: "DatabaseManager", code: 401, userInfo: [NSLocalizedDescriptionKey: "User not authenticated"])
        }
        
        print("Creating chat with senderId: \(senderId), receiverId: \(receiverId)")
        print("Current user: \(Auth.auth().currentUser?.uid ?? "nil")")
        
        let chatId = getChatId(senderId: senderId, receiverId: receiverId)
        let chatData: [String: Any] = [
            "participants": [senderId, receiverId],
            "lastUpdated": Timestamp(date: Date()),
            "createdAt": FieldValue.serverTimestamp()
        ]
        
        do {
            try await db.collection("chats").document(chatId).setData(chatData, merge: true)
            print("Successfully created/updated chat: \(chatId)")
        } catch {
            print("Error creating chat: \(error)")
            throw error
        }
        
        // Return the created/updated chat
        return Chat(
            id: chatId,
            participants: [senderId, receiverId],
            lastMessage: nil,
            createdAt: Date(),
            lastUpdated: Date(),
            isPinned: false,
            imageURL: nil
        )
    }
    
    func listenForChats(userId: String) -> AnyPublisher<[Chat], Error> {
        let subject = PassthroughSubject<[Chat], Error>()
        
        let listener = db.collection("chats")
            .whereField("participants", arrayContains: userId)
            .addSnapshotListener { snapshot, error in
                if let error = error {
                    subject.send(completion: .failure(error))
                    return
                }
                
                guard let documents = snapshot?.documents else {
                    subject.send([])
                    return
                }
                
                do {
                    let chats = try documents.compactMap { document -> Chat? in
                        let data = document.data()
                        
                        // Convert Firestore data to Chat object manually
                        let id = document.documentID
                        let participants = data["participants"] as? [String] ?? []
                        let createdAt = (data["createdAt"] as? Timestamp)?.dateValue() ?? Date()
                        let lastUpdated = (data["lastUpdated"] as? Timestamp)?.dateValue() ?? Date()
                        let isPinned = data["isPinned"] as? Bool ?? false
                        let imageURL = data["imageURL"] as? String
                        let unreadCount = data["unreadCount"] as? Int ?? 0
                        
                        // Handle lastMessage if it exists
                        var lastMessage: Chat.LastMessage?
                        if let lastMessageData = data["lastMessage"] as? [String: Any] {
                            let content = lastMessageData["content"] as? String ?? ""
                            let senderId = lastMessageData["senderId"] as? String ?? ""
                            let timestamp = (lastMessageData["timestamp"] as? Timestamp)?.dateValue() ?? Date()
                            let typeString = lastMessageData["type"] as? String ?? "text"
                            let type = Message.MessageType(rawValue: typeString) ?? .text
                            let isRead = lastMessageData["isRead"] as? Bool ?? false
                            
                            lastMessage = Chat.LastMessage(
                                content: content,
                                senderId: senderId,
                                timestamp: timestamp,
                                type: type,
                                isRead: isRead
                            )
                        }
                        
                        return Chat(
                            id: id,
                            participants: participants,
                            lastMessage: lastMessage,
                            createdAt: createdAt,
                            lastUpdated: lastUpdated,
                            isPinned: isPinned,
                            imageURL: imageURL,
                            unreadCount: unreadCount
                        )
                    }
                    subject.send(chats)
                } catch {
                    print("Error parsing chats: \(error)")
                    subject.send(completion: .failure(error))
                }
            }
        
        listeners["chats_\(userId)"] = listener
        return subject.eraseToAnyPublisher()
    }
    
    // MARK: - Users
    func getUser(id: String) async throws -> User {
        let document = try await db.collection("users").document(id).getDocument()
        guard let data = document.data() else {
            throw NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "User not found"])
        }
        return try User(dictionary: data)
    }
    
    func searchUsers(query: String) async throws -> [User] {
        let snapshot = try await db.collection("users")
            .whereField("name", isGreaterThanOrEqualTo: query)
            .whereField("name", isLessThanOrEqualTo: query + "\u{f8ff}")
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try User(dictionary: document.data())
        }
    }
    
    // MARK: - Helpers
    private func getChatId(senderId: String, receiverId: String) -> String {
        let sortedIds = [senderId, receiverId].sorted()
        return sortedIds.joined(separator: "_")
    }
    
    private func updateLastMessage(chatId: String, message: Message) async throws {
        let lastMessageData: [String: Any] = [
            "lastMessage": [
                "content": message.content,
                "senderId": message.senderId,
                "timestamp": Timestamp(date: message.timestamp),
                "type": message.type.rawValue
            ],
            "lastUpdated": Timestamp(date: Date())
        ]
        
        try await db.collection("chats").document(chatId).updateData(lastMessageData)
    }
    
    // MARK: - Contacts
    func fetchContacts() async throws -> [Contact] {
        guard let userId = AuthManager.shared.currentUserId else {
            throw NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "User not authenticated"])
        }
        
        let snapshot = try await db.collection("users")
            .document(userId)
            .collection("contacts")
            .order(by: "name")
            .getDocuments()
        
        return snapshot.documents.compactMap { document -> Contact? in
            try? Contact(from: document.data(), id: document.documentID)
        }
    }
    
    func addContact(name: String, phone: String, email: String) async throws {
        guard let userId = AuthManager.shared.currentUserId else {
            throw NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "User not authenticated"])
        }
        
        let contact = Contact(name: name, phone: phone, email: email)
        let contactData = contact.toDictionary()
        
        try await db.collection("users")
            .document(userId)
            .collection("contacts")
            .addDocument(data: contactData)
    }
    
    func deleteContact(_ contactId: String) async throws {
        guard let userId = AuthManager.shared.currentUserId else {
            throw NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "User not authenticated"])
        }
        
        try await db.collection("users")
            .document(userId)
            .collection("contacts")
            .document(contactId)
            .delete()
    }
    
    // MARK: - Calls
    func fetchCalls() async throws -> [CallRecord] {
        // Implement call fetching logic
        return []
    }
    
    func deleteCall(_ callId: String) async throws {
        try await db.collection("calls").document(callId).delete()
    }
    
    // MARK: - Chat Management
    func deleteChat(_ chatId: String) async throws {
        try await db.collection("chats").document(chatId).delete()
    }
    
    func pinChat(_ chatId: String) async throws {
        try await db.collection("chats").document(chatId).updateData(["isPinned": true])
    }
    
    func markChatAsRead(_ chatId: String) async throws {
        try await db.collection("chats").document(chatId).updateData(["unreadCount": 0])
    }
    
    func markMessagesAsRead(_ messageIds: [String]) async throws {
        let batch = db.batch()
        for messageId in messageIds {
            let messageRef = db.collection("messages").document(messageId)
            batch.updateData(["status": "read"], forDocument: messageRef)
        }
        try await batch.commit()
    }
    
    // MARK: - FCM Token
    func updateFCMToken(_ token: String) async throws {
        guard let userId = AuthManager.shared.currentUserId else { return }
        try await db.collection("users").document(userId).updateData(["deviceTokens": FieldValue.arrayUnion([token])])
    }
    
    func removeListeners() {
        listeners.values.forEach { $0.remove() }
        listeners.removeAll()
    }
    
    deinit {
        removeListeners()
    }
}

struct Chat: Identifiable, Codable {
    let id: String
    let participants: [String]
    var lastMessage: LastMessage?
    let createdAt: Date
    var lastUpdated: Date
    var isPinned: Bool = false
    var imageURL: String?
    var unreadCount: Int = 0
    
    var title: String {
        // This would typically be the other participant's name
        // For now, return a placeholder
        return "Chat"
    }
    
    var lastMessageTime: String {
        guard let lastMessage = lastMessage else { return "" }
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: lastMessage.timestamp)
    }
    
    struct LastMessage: Codable {
        let content: String
        let senderId: String
        let timestamp: Date
        let type: Message.MessageType
        var isRead: Bool = false
    }
}
