import SwiftUI
import FirebaseAuth
import FirebaseFirestore
import AuthenticationServices


class AuthManager: ObservableObject {
    static let shared = AuthManager()
    
    @Published var isAuthenticated = false
    @Published var currentUser: User?
    @Published var isLoading = false
    @Published var error: Error?
    @Published var isDemoMode = false
    @Published var needsPhoneVerification = false
    
    private let auth = Auth.auth()
    private let db = Firestore.firestore()
    
    private init() {
        setupAuthStateListener()
        setupGoogleSignIn()
    }
    
    var currentUserId: String? {
        auth.currentUser?.uid
    }
    
    private func setupAuthStateListener() {
        auth.addStateDidChangeListener { [weak self] _, user in
            Task { @MainActor in
                let wasAuthenticated = self?.isAuthenticated ?? false
                let isNowAuthenticated = user != nil
                
                if let user = user {
                    await self?.fetchUserData(userId: user.uid)
                    
                    // Only set as authenticated if user has completed phone verification
                    if let currentUser = self?.currentUser {
                        self?.isAuthenticated = !currentUser.phone.isEmpty
                    } else {
                        // If we can't fetch user data, assume they need phone verification
                        self?.isAuthenticated = false
                    }
                } else {
                    self?.currentUser = nil
                    self?.isAuthenticated = false
                }
                
                // Debug logging for authentication state changes
                print("Auth state changed: \(wasAuthenticated) -> \(self?.isAuthenticated ?? false)")
                
                // Force UI update if authentication state changed
                if wasAuthenticated != (self?.isAuthenticated ?? false) {
                    print("Authentication state changed - forcing UI update")
                }
            }
        }
    }
    
    func signIn(email: String, password: String) async throws {
        guard NetworkMonitorService.shared.isConnected else {
            throw AuthError.networkError
        }
        await MainActor.run {
            self.isLoading = true
        }
        defer { 
            Task { @MainActor in
                self.isLoading = false
            }
        }
        
        do {
            let result = try await auth.signIn(withEmail: email, password: password)
            await fetchUserData(userId: result.user.uid)
        } catch {
            await MainActor.run {
                self.error = error
            }
            throw error
        }
    }
    
    func signUp(email: String, password: String, name: String) async throws {
        guard NetworkMonitorService.shared.isConnected else {
            throw AuthError.networkError
        }
        await MainActor.run {
            self.isLoading = true
        }
        defer { 
            Task { @MainActor in
                self.isLoading = false
            }
        }
        
        do {
            let result = try await auth.createUser(withEmail: email, password: password)
            let user = User(
                id: result.user.uid,
                email: email,
                name: name,
                phone: "", // Phone will be set later in phone verification
                createdAt: Date()
            )
            try await createUserProfile(user)
            
            // Set phone verification flag for new users
            await MainActor.run {
                self.needsPhoneVerification = true
            }
        } catch {
            await MainActor.run {
                self.error = error
            }
            throw error
        }
    }
    
    func completePhoneVerification(phoneNumber: String) async throws {
        guard let userId = currentUserId else {
            throw AuthError.userNotFound
        }
        
        // Update user profile with phone number
        try await db.collection("users").document(userId).updateData([
            "phone": phoneNumber,
            "phoneVerified": true,
            "lastUpdated": Timestamp(date: Date())
        ])
        
        // Update local user data
        await MainActor.run {
            self.currentUser?.phone = phoneNumber
            self.needsPhoneVerification = false
            // Now that phone verification is complete, user is fully authenticated
            self.isAuthenticated = true
        }
    }
    
    func signOut() async throws {
        do {
            // Force sign out with multiple approaches for reliability
            try auth.signOut()
            
            // Brute force: Immediately set authentication state to false
            await MainActor.run {
                self.isAuthenticated = false
                self.currentUser = nil
                self.error = nil
            }
            
            // Additional safety: Force Firebase auth state to be cleared
            try await Task.sleep(nanoseconds: 100_000_000) // 0.1 second delay
            
            // Double-check and force state if needed
            if auth.currentUser != nil {
                try auth.signOut()
                await MainActor.run {
                    self.isAuthenticated = false
                    self.currentUser = nil
                }
            }
            
            // Force UI update to ensure navigation happens
            await MainActor.run {
                // Trigger a UI update by toggling the state
                self.isAuthenticated = false
                print("Sign out completed - forcing navigation to AuthView")
            }
            
        } catch {
            // Even if there's an error, force the user to be signed out
            await MainActor.run {
                self.isAuthenticated = false
                self.currentUser = nil
                self.error = error
                print("Sign out error but forcing navigation to AuthView: \(error)")
            }
            throw error
        }
    }
    
    func resetPassword(email: String) async throws {
        await MainActor.run {
            self.isLoading = true
        }
        defer { 
            Task { @MainActor in
                self.isLoading = false
            }
        }
        
        do {
            try await auth.sendPasswordReset(withEmail: email)
        } catch {
            await MainActor.run {
                self.error = error
            }
            throw error
        }
    }
    
    private func createUserProfile(_ user: User) async throws {
        let data: [String: Any] = [
            "id": user.id,
            "email": user.email,
            "name": user.name,
            "phone": user.phone,
            "createdAt": Timestamp(date: user.createdAt),
            "lastSeen": Timestamp(date: Date()),
            "isOnline": true
        ]
        
        try await db.collection("users").document(user.id).setData(data)
    }
    
    private func fetchUserData(userId: String) async {
        do {
            let document = try await db.collection("users").document(userId).getDocument()
            if let data = document.data() {
                // Add document ID to the data dictionary
                var userData = data
                userData["documentId"] = document.documentID
                let user = try User(dictionary: userData)
                await MainActor.run {
                    self.currentUser = user
                    // Check if user needs phone verification
                    self.needsPhoneVerification = user.phone.isEmpty
                }
            } else {
                // Document doesn't exist, create a basic user profile
                await MainActor.run {
                    self.currentUser = User(
                        id: userId,
                        email: Auth.auth().currentUser?.email ?? "",
                        name: "User",
                        phone: "",
                        photoURL: nil
                    )
                    // New user needs phone verification
                    self.needsPhoneVerification = true
                }
            }
        } catch {
            print("Error fetching user data: \(error)")
            // Create a fallback user profile
            await MainActor.run {
                self.currentUser = User(
                    id: userId,
                    email: Auth.auth().currentUser?.email ?? "",
                    name: "User",
                    phone: "",
                    photoURL: nil
                )
                // Fallback user needs phone verification
                self.needsPhoneVerification = true
            }
        }
    }
    
    func updateUserProfile(name: String? = nil, phone: String? = nil, photoURL: String? = nil, profileImage: UIImage? = nil) async throws {
        guard let userId = currentUserId else { return }
        
        var updateData: [String: Any] = [:]
        if let name = name { updateData["name"] = name }
        if let phone = phone { updateData["phone"] = phone }
        
        // Handle profile image upload
        if let profileImage = profileImage {
            let photoURL = try await uploadProfileImage(profileImage, userId: userId)
            updateData["photoURL"] = photoURL
        } else if let photoURL = photoURL {
            updateData["photoURL"] = photoURL
        }
        
        updateData["lastUpdated"] = Timestamp(date: Date())
        
        try await db.collection("users").document(userId).updateData(updateData)
        await fetchUserData(userId: userId)
    }
    
    private func uploadProfileImage(_ image: UIImage, userId: String) async throws -> String {
        return try await FirebaseStorageService.shared.uploadProfileImage(image, userId: userId)
    }
    
    func savePhoneNumber(_ phoneNumber: SavedPhoneNumber) async throws {
        guard let userId = currentUserId else { return }
        
        var updateData: [String: Any] = [:]
        updateData["savedPhoneNumbers"] = FieldValue.arrayUnion([phoneNumber])
        updateData["lastUpdated"] = Timestamp(date: Date())
        
        try await db.collection("users").document(userId).updateData(updateData)
        await fetchUserData(userId: userId)
    }
    
    func updateOnlineStatus(isOnline: Bool) {
        guard let userId = currentUserId else { return }
        
        let data: [String: Any] = [
            "isOnline": isOnline,
            "lastSeen": Timestamp(date: Date())
        ]
        
        db.collection("users").document(userId).updateData(data)
    }
    
    // MARK: - Google Sign-In
    private func setupGoogleSignIn() {
        // TODO: Add Google Sign-In SDK to project and uncomment the following code
        /*
        guard let path = Bundle.main.path(forResource: "GoogleService-Info", ofType: "plist"),
              let plist = NSDictionary(contentsOfFile: path),
              let clientId = plist["CLIENT_ID"] as? String else {
            print("GoogleService-Info.plist not found or CLIENT_ID missing")
            return
        }
        
        GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: clientId)
        */
        print("⚠️ Google Sign-In not configured - add GoogleSignIn SDK to project")
    }
    
    func signInWithGoogle() async throws {
        // TODO: Implement Google Sign-In when SDK is added to project
        throw AuthError.googleSignInNotAvailable
    }
    
    // MARK: - Demo Mode
    func enableDemoMode() {
        isDemoMode = true
        isAuthenticated = true
        
        // Create demo user
        currentUser = User(
            id: "demo-user",
            email: "demo@example.com",
            name: "Demo User",
            phone: "+1 (555) 123-4567",
            photoURL: nil,
            createdAt: Date(),
            lastSeen: Date(),
            isOnline: true
        )
    }
    
    func disableDemoMode() {
        isDemoMode = false
        isAuthenticated = false
        currentUser = nil
    }
    
    // MARK: - Enhanced Error Handling
    func handleAuthError(_ error: Error) -> String {
        if let authError = error as? AuthError {
            return authError.localizedDescription
        }
        
        if let firebaseError = error as NSError? {
            switch firebaseError.code {
            case AuthErrorCode.userNotFound.rawValue:
                return "No account found with this email address."
            case AuthErrorCode.wrongPassword.rawValue:
                return "Incorrect password. Please try again."
            case AuthErrorCode.invalidEmail.rawValue:
                return "Invalid email address format."
            case AuthErrorCode.emailAlreadyInUse.rawValue:
                return "An account with this email already exists."
            case AuthErrorCode.weakPassword.rawValue:
                return "Password is too weak. Please choose a stronger password."
            case AuthErrorCode.networkError.rawValue:
                return "Network error. Please check your connection."
            case AuthErrorCode.tooManyRequests.rawValue:
                return "Too many failed attempts. Please try again later."
            default:
                return "Authentication failed. Please try again."
            }
        }
        
        return "An unexpected error occurred. Please try again."
    }
    
    // MARK: - Phone Number Management
    func updatePhoneNumber(_ phoneNumber: String) async throws {
        guard let userId = currentUserId else { return }
        
        let data: [String: Any] = [
            "phone": phoneNumber,
            "lastUpdated": Timestamp(date: Date())
        ]
        
        try await db.collection("users").document(userId).updateData(data)
        await fetchUserData(userId: userId)
    }
    
    // MARK: - Account Management
    func deleteAccount() async throws {
        guard let userId = currentUserId else { return }
        
        // Delete user data from Firestore
        try await db.collection("users").document(userId).delete()
        
        // Delete user from Firebase Auth
        try await auth.currentUser?.delete()
        
        // Clear local state
        currentUser = nil
        isAuthenticated = false
    }
    
    // MARK: - Session Management
    func refreshUserSession() async {
        guard let user = auth.currentUser else { return }
        
        do {
            try await user.reload()
            await fetchUserData(userId: user.uid)
        } catch {
            print("Error refreshing user session: \(error)")
        }
    }
}

// MARK: - Saved Phone Number
struct SavedPhoneNumber: Identifiable, Codable {
    let id = UUID()
    let number: String
    let countryCode: String
    let areaCode: String
    let state: String?
    let country: String
    let createdAt: Date
    
    init(number: String, countryCode: String, areaCode: String, state: String? = nil, country: String) {
        self.number = number
        self.countryCode = countryCode
        self.areaCode = areaCode
        self.state = state
        self.country = country
        self.createdAt = Date()
    }
}

// MARK: - Auth Error Types
enum AuthError: Error, LocalizedError {
    case networkError
    case noPresentingViewController
    case noIDToken
    case invalidCredentials
    case userCancelled
    case googleSignInNotAvailable
    case unknownError
    case biometricNotAvailable
    case biometricFailed
    case userNotFound
    case custom(String)
    
    var errorDescription: String? {
        switch self {
        case .noPresentingViewController:
            return "Unable to present sign-in interface"
        case .noIDToken:
            return "Failed to get ID token from Google"
        case .invalidCredentials:
            return "Invalid credentials provided"
        case .userNotFound:
            return "User not found"
        case .userCancelled:
            return "Sign-in was cancelled by user"
        case .networkError:
            return "Network error occurred"
        case .googleSignInNotAvailable:
            return "Google Sign-In is not available. Please add the GoogleSignIn SDK to the project."
        case .unknownError:
            return "An unknown error occurred"
        case .biometricNotAvailable:
            return "Biometric authentication is not available on this device"
        case .biometricFailed:
            return "Biometric authentication failed"
        case .custom(let message):
            return message
        }
    }
}

struct User: Identifiable, Codable {
    let id: String
    let email: String
    var name: String
    var phone: String
    var photoURL: String?
    let createdAt: Date
    var lastSeen: Date?
    var isOnline: Bool
    var deviceTokens: [String]?
    var settings: UserSettings?
    var savedPhoneNumbers: [SavedPhoneNumber] = []
    
    struct UserSettings: Codable {
        var notifications: Bool
        var language: String
        var theme: String
        var autoTranslate: Bool
    }
    
    init(id: String, email: String, name: String, phone: String, photoURL: String? = nil,
         createdAt: Date = Date(), lastSeen: Date? = nil, isOnline: Bool = false) {
        self.id = id
        self.email = email
        self.name = name
        self.phone = phone
        self.photoURL = photoURL
        self.createdAt = createdAt
        self.lastSeen = lastSeen
        self.isOnline = isOnline
    }
    
    init(dictionary: [String: Any]) throws {
        // Use document ID as fallback if "id" field is missing
        let id = dictionary["id"] as? String ?? dictionary["documentId"] as? String ?? ""
        
        guard !id.isEmpty else {
            throw NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid user data: missing ID"])
        }
        
        self.id = id
        self.email = dictionary["email"] as? String ?? ""
        self.name = dictionary["name"] as? String ?? "User"
        self.phone = dictionary["phone"] as? String ?? ""
        self.photoURL = dictionary["photoURL"] as? String
        self.createdAt = (dictionary["createdAt"] as? Timestamp)?.dateValue() ?? Date()
        self.lastSeen = (dictionary["lastSeen"] as? Timestamp)?.dateValue()
        self.isOnline = dictionary["isOnline"] as? Bool ?? false
        self.deviceTokens = dictionary["deviceTokens"] as? [String]
        self.settings = nil
        self.savedPhoneNumbers = []
    }
}
