import SwiftUI
import FirebaseFirestore
import Combine

class SettingsManager: ObservableObject {
    static let shared = SettingsManager()
    
    @Published var settings: AppSettings = AppSettings()
    @Published var isLoading = false
    @Published var error: Error?
    
    private let db = Firestore.firestore()
    private var cancellables = Set<AnyCancellable>()
    
    private init() {
        loadSettings()
        // Apply the saved theme on initialization
        applyTheme(settings.theme)
    }
    
    // MARK: - Settings Management
    func loadSettings() {
        // Load from UserDefaults first
        if let data = UserDefaults.standard.data(forKey: "appSettings"),
           let savedSettings = try? JSONDecoder().decode(AppSettings.self, from: data) {
            settings = savedSettings
        }
        
        // Then sync with Firebase if user is logged in
        if AuthManager.shared.isAuthenticated {
            Task {
                await syncWithFirebase()
            }
        }
    }
    
    func saveSettings() {
        // Save to UserDefaults
        if let data = try? JSONEncoder().encode(settings) {
            UserDefaults.standard.set(data, forKey: "appSettings")
        }
        
        // Save to Firebase if user is logged in
        if AuthManager.shared.isAuthenticated {
            Task {
                await saveToFirebase()
            }
        }
    }
    
    private func syncWithFirebase() async {
        guard let userId = AuthManager.shared.currentUserId else { return }
        
        do {
            let document = try await db.collection("users")
                .document(userId)
                .collection("settings")
                .document("appSettings")
                .getDocument()
            
            if let data = document.data(),
               let firebaseSettings = try? AppSettings(from: data) {
                await MainActor.run {
                    // Merge settings, giving priority to Firebase
                    self.settings = self.mergeSettings(local: self.settings, remote: firebaseSettings)
                }
            }
        } catch {
            print("Error syncing settings with Firebase: \(error)")
        }
    }
    
    private func saveToFirebase() async {
        guard let userId = AuthManager.shared.currentUserId else { return }
        
        do {
            let data = settings.toDictionary()
            try await db.collection("users")
                .document(userId)
                .collection("settings")
                .document("appSettings")
                .setData(data)
        } catch {
            print("Error saving settings to Firebase: \(error)")
        }
    }
    
    private func mergeSettings(local: AppSettings, remote: AppSettings) -> AppSettings {
        // Merge logic - prioritize Firebase settings but keep local changes
        var mergedSettings = AppSettings()
        mergedSettings.theme = remote.theme
        mergedSettings.language = remote.language
        mergedSettings.sourceLanguage = remote.sourceLanguage
        mergedSettings.targetLanguage = remote.targetLanguage
        mergedSettings.notifications = remote.notifications
        mergedSettings.privacy = remote.privacy
        mergedSettings.audio = remote.audio
        mergedSettings.video = remote.video
        mergedSettings.translation = remote.translation
        mergedSettings.lastUpdated = Date()
        return mergedSettings
    }
    
    // MARK: - Theme Management
    func setTheme(_ theme: AppTheme) {
        settings.theme = theme
        saveSettings()
        applyTheme(theme)
    }
    
    func setChatBubbleSentColor(_ color: ChatBubbleColor) {
        settings.chatBubbles.sentColor = color
        saveSettings()
    }
    
    func setChatBubbleReceivedColor(_ color: ChatBubbleColor) {
        settings.chatBubbles.receivedColor = color
        saveSettings()
    }
    
    func setCallInterfaceBackground(_ color: CallBackgroundColor) {
        settings.callInterface.background = color
        saveSettings()
    }
    
    private func applyTheme(_ theme: AppTheme) {
        // Apply theme to the app
        DispatchQueue.main.async {
            switch theme {
            case .light:
                // Force light mode
                if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                    windowScene.windows.forEach { window in
                        window.overrideUserInterfaceStyle = .light
                    }
                }
            case .dark:
                // Force dark mode
                if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                    windowScene.windows.forEach { window in
                        window.overrideUserInterfaceStyle = .dark
                    }
                }
            case .system:
                // Use system theme
                if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                    windowScene.windows.forEach { window in
                        window.overrideUserInterfaceStyle = .unspecified
                    }
                }
            default:
                // For gradient themes, use system theme as base and apply gradient via UI
                if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                    windowScene.windows.forEach { window in
                        window.overrideUserInterfaceStyle = .unspecified
                    }
                }
            }
        }
    }
    
    // MARK: - Language Management
    func setLanguage(_ language: String) {
        settings.language = language
        saveSettings()
    }
    
    func setSourceLanguage(_ language: String) {
        settings.sourceLanguage = language
        saveSettings()
    }
    
    func setTargetLanguage(_ language: String) {
        settings.targetLanguage = language
        saveSettings()
    }
    
    // MARK: - Notification Settings
    func updateNotificationSettings(_ notifications: AppSettings.NotificationSettings) {
        settings.notifications = notifications
        saveSettings()
    }
    
    func setMessageNotifications(_ enabled: Bool) {
        settings.notifications.messages = enabled
        saveSettings()
    }
    
    func setCallNotifications(_ enabled: Bool) {
        settings.notifications.calls = enabled
        saveSettings()
    }
    
    func setTranslationNotifications(_ enabled: Bool) {
        settings.notifications.translations = enabled
        saveSettings()
    }
    
    func setPushNotifications(_ enabled: Bool) {
        settings.notifications.push = enabled
        saveSettings()
    }
    
    // MARK: - Privacy Settings
    func updatePrivacySettings(_ privacy: AppSettings.PrivacySettings) {
        settings.privacy = privacy
        saveSettings()
    }
    
    // MARK: - Audio Settings
    func updateAudioSettings(_ audio: AppSettings.AudioSettings) {
        settings.audio = audio
        saveSettings()
    }
    
    func setVolume(_ volume: Float) {
        settings.audio.volume = volume
        saveSettings()
    }
    
    func setRingtone(_ ringtone: String) {
        settings.audio.ringtone = ringtone
        saveSettings()
    }
    
    func setVibration(_ enabled: Bool) {
        settings.audio.vibration = enabled
        saveSettings()
    }
    
    func setSpeakerMode(_ enabled: Bool) {
        settings.audio.speakerMode = enabled
        saveSettings()
    }
    
    // MARK: - Video Settings
    func updateVideoSettings(_ video: AppSettings.VideoSettings) {
        settings.video = video
        saveSettings()
    }
    
    func setVideoQuality(_ quality: VideoQuality) {
        settings.video.quality = quality
        saveSettings()
    }
    
    func setAutoStartVideo(_ enabled: Bool) {
        settings.video.autoStart = enabled
        saveSettings()
    }
    
    func setMirrorFrontCamera(_ enabled: Bool) {
        settings.video.mirrorFrontCamera = enabled
        saveSettings()
    }
    
    // MARK: - Translation Settings
    func updateTranslationSettings(_ translation: AppSettings.TranslationSettings) {
        settings.translation = translation
        saveSettings()
    }
    
    func setAutoTranslate(_ enabled: Bool) {
        settings.translation.autoTranslate = enabled
        saveSettings()
    }
    
    func setTranslationProvider(_ provider: TranslationProvider) {
        settings.translation.provider = provider
        saveSettings()
    }
    
    func setVoiceEnabled(_ enabled: Bool) {
        settings.translation.voiceEnabled = enabled
        saveSettings()
    }
    
    func setTranslationConfidence(_ confidence: Float) {
        settings.translation.confidence = confidence
        saveSettings()
    }
    
    // MARK: - Reset Settings
    func resetToDefaults() {
        settings = AppSettings()
        saveSettings()
    }
    
    func exportSettings() -> Data? {
        return try? JSONEncoder().encode(settings)
    }
    
    func importSettings(from data: Data) -> Bool {
        do {
            let importedSettings = try JSONDecoder().decode(AppSettings.self, from: data)
            settings = importedSettings
            saveSettings()
            return true
        } catch {
            print("Error importing settings: \(error)")
            return false
        }
    }
}

// MARK: - App Settings Model
struct AppSettings: Codable {
    var theme: AppTheme = .system
    var language: String = "en"
    var sourceLanguage: String = "auto"
    var targetLanguage: String = "es"
    var notifications: NotificationSettings = NotificationSettings()
    var privacy: PrivacySettings = PrivacySettings()
    var audio: AudioSettings = AudioSettings()
    var video: VideoSettings = VideoSettings()
    var translation: TranslationSettings = TranslationSettings()
    var chatBubbles: ChatBubbleSettings = ChatBubbleSettings()
    var callInterface: CallInterfaceSettings = CallInterfaceSettings()
    var lastUpdated: Date = Date()
    
    struct NotificationSettings: Codable {
        var messages: Bool = true
        var calls: Bool = true
        var translations: Bool = true
        var push: Bool = true
    }
    
    struct PrivacySettings: Codable {
        var showOnlineStatus: Bool = true
        var allowCalls: Bool = true
        var allowMessages: Bool = true
        var shareLocation: Bool = false
    }
    
    struct AudioSettings: Codable {
        var volume: Float = 0.8
        var ringtone: String = "default"
        var vibration: Bool = true
        var speakerMode: Bool = false
    }
    
    struct VideoSettings: Codable {
        var quality: VideoQuality = .high
        var autoStart: Bool = false
        var mirrorFrontCamera: Bool = true
    }
    
    struct TranslationSettings: Codable {
        var autoTranslate: Bool = true
        var provider: TranslationProvider = .openAI
        var voiceEnabled: Bool = true
        var confidence: Float = 0.8
    }
    
    struct ChatBubbleSettings: Codable {
        var sentColor: ChatBubbleColor = .blue
        var receivedColor: ChatBubbleColor = .green
        var cornerRadius: Double = 16.0
        var fontSize: Double = 16.0
    }
    
    struct CallInterfaceSettings: Codable {
        var background: CallBackgroundColor = .dark
        var buttonColor: String = "blue"
        var textColor: String = "white"
        var showWaveform: Bool = true
    }
    
    init() {}
    
    init(from data: [String: Any]) throws {
        theme = AppTheme(rawValue: data["theme"] as? String ?? "system") ?? .system
        language = data["language"] as? String ?? "en"
        sourceLanguage = data["sourceLanguage"] as? String ?? "auto"
        targetLanguage = data["targetLanguage"] as? String ?? "es"
        
        if let notificationsData = data["notifications"] as? [String: Any] {
            notifications = NotificationSettings(
                messages: notificationsData["messages"] as? Bool ?? true,
                calls: notificationsData["calls"] as? Bool ?? true,
                translations: notificationsData["translations"] as? Bool ?? true,
                push: notificationsData["push"] as? Bool ?? true
            )
        }
        
        if let privacyData = data["privacy"] as? [String: Any] {
            privacy = PrivacySettings(
                showOnlineStatus: privacyData["showOnlineStatus"] as? Bool ?? true,
                allowCalls: privacyData["allowCalls"] as? Bool ?? true,
                allowMessages: privacyData["allowMessages"] as? Bool ?? true,
                shareLocation: privacyData["shareLocation"] as? Bool ?? false
            )
        }
        
        if let audioData = data["audio"] as? [String: Any] {
            audio = AudioSettings(
                volume: audioData["volume"] as? Float ?? 0.8,
                ringtone: audioData["ringtone"] as? String ?? "default",
                vibration: audioData["vibration"] as? Bool ?? true,
                speakerMode: audioData["speakerMode"] as? Bool ?? false
            )
        }
        
        if let videoData = data["video"] as? [String: Any] {
            video = VideoSettings(
                quality: VideoQuality(rawValue: videoData["quality"] as? String ?? "high") ?? .high,
                autoStart: videoData["autoStart"] as? Bool ?? false,
                mirrorFrontCamera: videoData["mirrorFrontCamera"] as? Bool ?? true
            )
        }
        
        if let translationData = data["translation"] as? [String: Any] {
            translation = TranslationSettings(
                autoTranslate: translationData["autoTranslate"] as? Bool ?? true,
                provider: TranslationProvider(rawValue: translationData["provider"] as? String ?? "openAI") ?? .openAI,
                voiceEnabled: translationData["voiceEnabled"] as? Bool ?? true,
                confidence: translationData["confidence"] as? Float ?? 0.8
            )
        }
        
        lastUpdated = (data["lastUpdated"] as? Timestamp)?.dateValue() ?? Date()
    }
    
    func toDictionary() -> [String: Any] {
        return [
            "theme": theme.rawValue,
            "language": language,
            "sourceLanguage": sourceLanguage,
            "targetLanguage": targetLanguage,
            "notifications": [
                "messages": notifications.messages,
                "calls": notifications.calls,
                "translations": notifications.translations,
                "push": notifications.push
            ],
            "privacy": [
                "showOnlineStatus": privacy.showOnlineStatus,
                "allowCalls": privacy.allowCalls,
                "allowMessages": privacy.allowMessages,
                "shareLocation": privacy.shareLocation
            ],
            "audio": [
                "volume": audio.volume,
                "ringtone": audio.ringtone,
                "vibration": audio.vibration,
                "speakerMode": audio.speakerMode
            ],
            "video": [
                "quality": video.quality.rawValue,
                "autoStart": video.autoStart,
                "mirrorFrontCamera": video.mirrorFrontCamera
            ],
            "translation": [
                "autoTranslate": translation.autoTranslate,
                "provider": translation.provider.rawValue,
                "voiceEnabled": translation.voiceEnabled,
                "confidence": translation.confidence
            ],
            "lastUpdated": Timestamp(date: lastUpdated)
        ]
    }
}

// MARK: - Enums
enum AppTheme: String, CaseIterable, Codable {
    case light = "light"
    case dark = "dark"
    case system = "system"
    case ocean = "ocean"
    case sunset = "sunset"
    case forest = "forest"
    case lavender = "lavender"
    case fire = "fire"
    case arctic = "arctic"
    case cosmic = "cosmic"
    
    var displayName: String {
        switch self {
        case .light: return "Light"
        case .dark: return "Dark"
        case .system: return "System"
        case .ocean: return "Ocean"
        case .sunset: return "Sunset"
        case .forest: return "Forest"
        case .lavender: return "Lavender"
        case .fire: return "Fire"
        case .arctic: return "Arctic"
        case .cosmic: return "Cosmic"
        }
    }
    
    var icon: String {
        switch self {
        case .light: return "sun.max.fill"
        case .dark: return "moon.fill"
        case .system: return "gear"
        case .ocean: return "drop.fill"
        case .sunset: return "sunset.fill"
        case .forest: return "leaf.fill"
        case .lavender: return "sparkles"
        case .fire: return "flame.fill"
        case .arctic: return "snowflake"
        case .cosmic: return "star.fill"
        }
    }
    
    var gradientColors: [Color] {
        switch self {
        case .light:
            return [Color.white, Color.gray.opacity(0.1)]
        case .dark:
            return [Color.black, Color.gray.opacity(0.3)]
        case .system:
            return [Color.primary, Color.secondary]
        case .ocean:
            return [Color.blue, Color.cyan, Color.teal]
        case .sunset:
            return [Color.orange, Color.pink, Color.purple]
        case .forest:
            return [Color.green, Color.mint, Color.teal]
        case .lavender:
            return [Color.purple, Color.pink, Color.blue]
        case .fire:
            return [Color.red, Color.orange, Color.yellow]
        case .arctic:
            return [Color.blue.opacity(0.8), Color.white, Color.cyan]
        case .cosmic:
            return [Color.purple, Color.indigo, Color.black]
        }
    }
    
    var isGradient: Bool {
        switch self {
        case .light, .dark, .system:
            return false
        default:
            return true
        }
    }
}

enum VideoQuality: String, CaseIterable, Codable {
    case low = "low"
    case medium = "medium"
    case high = "high"
    case ultra = "ultra"
    
    var displayName: String {
        switch self {
        case .low:
            return "Low (240p)"
        case .medium:
            return "Medium (480p)"
        case .high:
            return "High (720p)"
        case .ultra:
            return "Ultra (1080p)"
        }
    }
}

enum TranslationProvider: String, CaseIterable, Codable {
    case google = "google"
    case openAI = "openAI"
    case azure = "azure"
    
    var displayName: String {
        switch self {
        case .google:
            return "Google Translate"
        case .openAI:
            return "OpenAI GPT"
        case .azure:
            return "Azure Translator"
        }
    }
}

// MARK: - Chat Bubble Color Enum
enum ChatBubbleColor: String, CaseIterable, Codable {
    case blue = "blue"
    case green = "green"
    case purple = "purple"
    case orange = "orange"
    case red = "red"
    case pink = "pink"
    case teal = "teal"
    case indigo = "indigo"
    
    var color: Color {
        switch self {
        case .blue: return .blue
        case .green: return .green
        case .purple: return .purple
        case .orange: return .orange
        case .red: return .red
        case .pink: return .pink
        case .teal: return .teal
        case .indigo: return .indigo
        }
    }
}

// MARK: - Call Background Color Enum
enum CallBackgroundColor: String, CaseIterable, Codable {
    case dark = "dark"
    case light = "light"
    case blue = "blue"
    case purple = "purple"
    case green = "green"
    case red = "red"
    case orange = "orange"
    case pink = "pink"
    case teal = "teal"
    case indigo = "indigo"
    case mint = "mint"
    case yellow = "yellow"
    case gray = "gray"
    
    var color: Color {
        switch self {
        case .dark: return .black
        case .light: return .white
        case .blue: return .blue.opacity(0.8)
        case .purple: return .purple.opacity(0.8)
        case .green: return .green.opacity(0.8)
        case .red: return .red.opacity(0.8)
        case .orange: return .orange.opacity(0.8)
        case .pink: return .pink.opacity(0.8)
        case .teal: return .teal.opacity(0.8)
        case .indigo: return .indigo.opacity(0.8)
        case .mint: return .mint.opacity(0.8)
        case .yellow: return .yellow.opacity(0.8)
        case .gray: return .gray.opacity(0.8)
        }
    }
    
    var displayName: String {
        switch self {
        case .dark: return "Dark"
        case .light: return "Light"
        case .blue: return "Blue"
        case .purple: return "Purple"
        case .green: return "Green"
        case .red: return "Red"
        case .orange: return "Orange"
        case .pink: return "Pink"
        case .teal: return "Teal"
        case .indigo: return "Indigo"
        case .mint: return "Mint"
        case .yellow: return "Yellow"
        case .gray: return "Gray"
        }
    }
}
