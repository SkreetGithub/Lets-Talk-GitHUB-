import Foundation
import UIKit
import FirebaseStorage

// MARK: - Firebase Storage Service
class FirebaseStorageService: ObservableObject {
    static let shared = FirebaseStorageService()
    
    private let storage = Storage.storage()
    
    private init() {}
    
    // MARK: - Profile Image Upload
    func uploadProfileImage(_ image: UIImage, userId: String) async throws -> String {
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            throw NSError(domain: "FirebaseStorageService", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to compress image"])
        }
        
        let storageRef = storage.reference().child("profile_images/\(userId).jpg")
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpeg"
        
        _ = try await storageRef.putDataAsync(imageData, metadata: metadata)
        return try await storageRef.downloadURL().absoluteString
    }
    
    // MARK: - Chat Media Upload
    func uploadChatImage(_ image: UIImage, chatId: String, messageId: String) async throws -> String {
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            throw NSError(domain: "FirebaseStorageService", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to compress image"])
        }
        
        let storageRef = storage.reference().child("chat_images/\(chatId)/\(messageId).jpg")
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpeg"
        
        _ = try await storageRef.putDataAsync(imageData, metadata: metadata)
        return try await storageRef.downloadURL().absoluteString
    }
    
    // MARK: - File Upload
    func uploadFile(_ data: Data, fileName: String, folder: String) async throws -> String {
        let storageRef = storage.reference().child("\(folder)/\(fileName)")
        
        _ = try await storageRef.putDataAsync(data)
        return try await storageRef.downloadURL().absoluteString
    }
    
    // MARK: - Delete File
    func deleteFile(at path: String) async throws {
        let storageRef = storage.reference().child(path)
        try await storageRef.delete()
    }
    
    // MARK: - Get Download URL
    func getDownloadURL(for path: String) async throws -> String {
        let storageRef = storage.reference().child(path)
        return try await storageRef.downloadURL().absoluteString
    }
}
