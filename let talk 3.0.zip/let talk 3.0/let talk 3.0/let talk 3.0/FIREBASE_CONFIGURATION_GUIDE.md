# Firebase Configuration Guide

## Issues to Fix

### 1. Bundle ID Inconsistency
**Problem**: Firebase expects Bundle ID: `merchant.com.upappllc.Let-s-Talk-`

**Solution**: 
1. Open your Xcode project
2. Select your target
3. Go to "Signing & Capabilities"
4. Change the Bundle Identifier to: `merchant.com.upappllc.Let-s-Talk-`

### 2. Firestore Permissions
**Problem**: "Missing or insufficient permissions" for chats collection

**Solution**: Update your Firestore security rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read/write their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      
      // Users can read/write their own contacts
      match /contacts/{contactId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
    
    // Messages - users can read/write messages they're involved in
    match /messages/{messageId} {
      allow read, write: if request.auth != null && 
        (resource.data.senderId == request.auth.uid || 
         resource.data.receiverId == request.auth.uid);
    }
    
    // Chats - users can read/write chats they're participants in
    match /chats/{chatId} {
      allow read, write: if request.auth != null && 
        request.auth.uid in resource.data.participants;
    }
    
    // Calls - users can read/write calls they're involved in
    match /calls/{callId} {
      allow read, write: if request.auth != null && 
        (resource.data.callerId == request.auth.uid || 
         resource.data.calleeId == request.auth.uid);
    }
  }
}
```

### 3. Push Notifications Setup
**Problem**: "no valid 'aps-environment' entitlement string found"

**Solution**:
1. In Xcode, go to your target's "Signing & Capabilities"
2. Click "+ Capability"
3. Add "Push Notifications"
4. Add "Background Modes" and enable:
   - Background processing
   - Remote notifications
   - Voice over IP
   - Audio

### 4. Google Sign-In Setup
**Problem**: "Google Sign-In not configured"

**Solution**:
1. Add GoogleSignIn SDK to your project via Swift Package Manager:
   - URL: `https://github.com/google/GoogleSignIn-iOS`
2. Add the following to your `let_talk_3_0App.swift`:

```swift
import GoogleSignIn

// In your App struct's init() or onAppear:
if let path = Bundle.main.path(forResource: "GoogleService-Info", ofType: "plist"),
   let plist = NSDictionary(contentsOfFile: path),
   let clientId = plist["CLIENT_ID"] as? String {
    GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: clientId)
}
```

### 5. User Data Error
**Problem**: "Invalid user data"

**Solution**: Check your User model initialization in AuthManager.swift. Make sure the User struct can handle the data from Firestore properly.

### 6. Main Thread Publishing
**Problem**: "Publishing changes from background threads is not allowed"

**Solution**: All @Published property updates should be wrapped in `MainActor.run` or use `.receive(on: DispatchQueue.main)` for Combine publishers.

## Testing Checklist

- [ ] Bundle ID matches Firebase configuration
- [ ] Firestore rules allow proper access
- [ ] Push notifications capability added
- [ ] Google Sign-In SDK added and configured
- [ ] All privacy descriptions added to Info.plist
- [ ] All @Published updates happen on main thread
- [ ] User data model handles Firestore data correctly

## Additional Notes

1. **Info.plist**: The provided Info.plist includes all required privacy usage descriptions
2. **Background Modes**: Configured for audio, VoIP, and background processing
3. **Firebase Proxy**: Disabled to allow manual configuration
4. **Bundle ID**: Set to match Firebase configuration exactly

After making these changes, clean and rebuild your project.
