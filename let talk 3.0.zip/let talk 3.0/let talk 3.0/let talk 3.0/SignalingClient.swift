import Foundation
import FirebaseFirestore
import FirebaseAuth
import Combine
import WebRTC

// MARK: - Signaling Types
// Note: SignalingMessage, SessionDescription, and IceCandidate are defined in FirebaseSignalingService.swift

protocol SignalingClientDelegate: AnyObject {
    func signalingClient(_ client: SignalingClient, didReceiveOffer offer: RTCSessionDescription)
    func signalingClient(_ client: SignalingClient, didReceiveAnswer answer: RTCSessionDescription)
    func signalingClient(_ client: SignalingClient, didReceiveCandidate candidate: RTCIceCandidate)
    func signalingClient(_ client: SignalingClient, didReceiveCallEnd callId: String)
    func signalingClient(_ client: SignalingClient, didFailWithError error: Error)
}

class SignalingClient: ObservableObject {
    weak var delegate: SignalingClientDelegate?
    
    private let db = Firestore.firestore()
    private var callListener: ListenerRegistration?
    private var currentCallId: String?
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Signaling Methods
    func send(message: SignalingMessageType) {
        // Implement signaling message sending
        // This would typically send the message to Firebase or a signaling server
        print("Sending signaling message: \(message)")
    }
    
    // MARK: - Call Management
    func createCall(to targetNumber: String, isVideo: Bool = false) async throws -> String {
        guard let currentUserId = AuthManager.shared.currentUserId else {
            throw SignalingError.userNotAuthenticated
        }
        
        let callId = "call_\(UUID().uuidString)"
        currentCallId = callId
        
        let callData: [String: Any] = [
            "id": callId,
            "callerId": currentUserId,
            "calleeNumber": targetNumber,
            "isVideo": isVideo,
            "status": "ringing",
            "createdAt": Timestamp(date: Date()),
            "updatedAt": Timestamp(date: Date())
        ]
        
        try await db.collection("calls").document(callId).setData(callData)
        
        // Start listening for call updates
        startListeningForCall(callId)
        
        return callId
    }
    
    func answerCall(callId: String, isVideo: Bool = false) async throws {
        guard let currentUserId = AuthManager.shared.currentUserId else {
            throw SignalingError.userNotAuthenticated
        }
        
        let updateData: [String: Any] = [
            "status": "answered",
            "answeredAt": Timestamp(date: Date()),
            "updatedAt": Timestamp(date: Date())
        ]
        
        try await db.collection("calls").document(callId).updateData(updateData)
        
        // Start listening for call updates
        startListeningForCall(callId)
    }
    
    func endCall(callId: String) async throws {
        let updateData: [String: Any] = [
            "status": "ended",
            "endedAt": Timestamp(date: Date()),
            "updatedAt": Timestamp(date: Date())
        ]
        
        try await db.collection("calls").document(callId).updateData(updateData)
        
        // Stop listening
        stopListening()
    }
    
    // MARK: - Signaling Messages
    func sendOffer(callId: String, offer: RTCSessionDescription) async throws {
        let offerData: [String: Any] = [
            "type": "offer",
            "sdp": offer.sdp,
            "timestamp": Timestamp(date: Date())
        ]
        
        try await db.collection("calls")
            .document(callId)
            .collection("signaling")
            .addDocument(data: offerData)
    }
    
    func sendAnswer(callId: String, answer: RTCSessionDescription) async throws {
        let answerData: [String: Any] = [
            "type": "answer",
            "sdp": answer.sdp,
            "timestamp": Timestamp(date: Date())
        ]
        
        try await db.collection("calls")
            .document(callId)
            .collection("signaling")
            .addDocument(data: answerData)
    }
    
    func sendCandidate(callId: String, candidate: RTCIceCandidate) async throws {
        let candidateData: [String: Any] = [
            "type": "candidate",
            "candidate": candidate.sdp,
            "sdpMLineIndex": candidate.sdpMLineIndex,
            "sdpMid": candidate.sdpMid ?? "",
            "timestamp": Timestamp(date: Date())
        ]
        
        try await db.collection("calls")
            .document(callId)
            .collection("signaling")
            .addDocument(data: candidateData)
    }
    
    // MARK: - Listening
    private func startListeningForCall(_ callId: String) {
        callListener = db.collection("calls")
            .document(callId)
            .collection("signaling")
            .order(by: "timestamp", descending: false)
            .addSnapshotListener { [weak self] snapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    self.delegate?.signalingClient(self, didFailWithError: error)
                    return
                }
                
                guard let snapshot = snapshot else { return }
                
                for document in snapshot.documentChanges {
                    if document.type == .added {
                        self.handleSignalingMessage(document.document.data())
                    }
                }
            }
    }
    
    func startListeningForIncomingCalls() {
        guard let currentUserId = AuthManager.shared.currentUserId else { return }
        
        // Listen for calls where current user is the callee
        callListener = db.collection("calls")
            .whereField("calleeNumber", isEqualTo: currentUserId) // Use phone number instead of calleeId
            .whereField("status", isEqualTo: "ringing")
            .addSnapshotListener { [weak self] snapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    print("Error listening for incoming calls: \(error)")
                    return
                }
                
                guard let snapshot = snapshot else { return }
                
                for document in snapshot.documentChanges {
                    if document.type == .added {
                        self.handleIncomingCall(document.document.data())
                    }
                }
            }
    }
    
    private func handleIncomingCall(_ data: [String: Any]) {
        guard let callerId = data["callerId"] as? String,
              let isVideo = data["isVideo"] as? Bool,
              let callId = data["id"] as? String else { return }
        
        // Show inbound call screen
        WebRTCService.shared.handleIncomingCall(callId: callId, from: callerId, isVideo: isVideo)
    }
    
    private func handleSignalingMessage(_ data: [String: Any]) {
        guard let type = data["type"] as? String else { return }
        
        switch type {
        case "offer":
            if let sdp = data["sdp"] as? String {
                let offer = RTCSessionDescription(type: .offer, sdp: sdp)
                delegate?.signalingClient(self, didReceiveOffer: offer)
            }
            
        case "answer":
            if let sdp = data["sdp"] as? String {
                let answer = RTCSessionDescription(type: .answer, sdp: sdp)
                delegate?.signalingClient(self, didReceiveAnswer: answer)
            }
            
        case "candidate":
            if let candidate = data["candidate"] as? String,
               let sdpMLineIndex = data["sdpMLineIndex"] as? Int32,
               let sdpMid = data["sdpMid"] as? String {
                let iceCandidate = RTCIceCandidate(sdp: candidate, sdpMLineIndex: sdpMLineIndex, sdpMid: sdpMid)
                delegate?.signalingClient(self, didReceiveCandidate: iceCandidate)
            }
            
        default:
            break
        }
    }
    
    func stopListening() {
        callListener?.remove()
        callListener = nil
        currentCallId = nil
    }
    
    // MARK: - Multi-Call Support
    func addParticipantToCall(callId: String, participantId: String) async throws {
        let participantData: [String: Any] = [
            "participantId": participantId,
            "joinedAt": Timestamp(date: Date())
        ]
        
        try await db.collection("calls")
            .document(callId)
            .collection("participants")
            .document(participantId)
            .setData(participantData)
    }
    
    func removeParticipantFromCall(callId: String, participantId: String) async throws {
        try await db.collection("calls")
            .document(callId)
            .collection("participants")
            .document(participantId)
            .delete()
    }
    
    // MARK: - Call Status Updates
    func updateCallStatus(callId: String, status: CallStatus) async throws {
        let updateData: [String: Any] = [
            "status": status.rawValue,
            "updatedAt": Timestamp(date: Date())
        ]
        
        try await db.collection("calls").document(callId).updateData(updateData)
    }
    
    // MARK: - Call History
    func getCallHistory(limit: Int = 50) async throws -> [CallRecord] {
        guard let currentUserId = AuthManager.shared.currentUserId else {
            throw SignalingError.userNotAuthenticated
        }
        
        let snapshot = try await db.collection("calls")
            .whereField("callerId", isEqualTo: currentUserId)
            .order(by: "createdAt", descending: true)
            .limit(to: limit)
            .getDocuments()
        
        return snapshot.documents.compactMap { document in
            let data = document.data()
            // Create a mock Contact for now - this should be replaced with actual contact lookup
            let mockContact = Contact(name: "Unknown", phone: "", email: "")
            
            return CallRecord(
                id: document.documentID,
                contact: mockContact,
                type: (data["isVideo"] as? Bool ?? false) ? .video : .audio,
                timestamp: (data["createdAt"] as? Timestamp)?.dateValue() ?? Date(),
                duration: data["duration"] as? Int ?? 0,
                isMissed: (data["status"] as? String) == "missed",
                direction: (data["direction"] as? String) == "incoming" ? .incoming : .outgoing
            )
        }
    }
    
    deinit {
        stopListening()
    }
}

// MARK: - Data Models
// Note: CallRecord is defined in CallsView.swift

// Note: CallStatus is defined in FirebaseSignalingService.swift

enum SignalingError: Error, LocalizedError {
    case userNotAuthenticated
    case callNotFound
    case invalidSignalingData
    case networkError
    
    var errorDescription: String? {
        switch self {
        case .userNotAuthenticated:
            return "User not authenticated"
        case .callNotFound:
            return "Call not found"
        case .invalidSignalingData:
            return "Invalid signaling data"
        case .networkError:
            return "Network error occurred"
        }
    }
}

enum CallRecordError: Error, LocalizedError {
    case invalidData
    
    var errorDescription: String? {
        return "Invalid call record data"
    }
}
