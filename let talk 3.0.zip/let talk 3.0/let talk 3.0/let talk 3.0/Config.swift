import Foundation

enum Config {
    // API Keys - Updated to match JavaScript version
    static let openAIAPIKey = "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"
    static let googleTranslateAPIKey = "YOUR_GOOGLE_TRANSLATE_API_KEY"
    static let firebaseConfig = [
        "apiKey": "AIzaSyBMVCIGfLXoJ_n_kPYczvLQb2knzyTvZjw",
        "authDomain": "lets-talk-b777f.firebaseapp.com",
        "projectId": "lets-talk-b777f",
        "storageBucket": "lets-talk-b777f.firebasestorage.app",
        "messagingSenderId": "362064879308",
        "appId": "1:362064879308:web:e06488ede1511810402c69",
        "measurementId": "G-B63QSZSKF0"
    ]
    
    // WebRTC Configuration
    static let webRTCIceServers = [
        ["url": "stun:stun.l.google.com:19302"],
        ["url": "stun:stun1.l.google.com:19302"]
    ]
    
    // App Settings
    static let maxReconnectAttempts = 5
    static let reconnectDelay: TimeInterval = 3.0
    static let messagePageSize = 50
    static let maxImageSize = 1024 * 1024 * 5 // 5MB
    
    // Feature Flags
    static let enableVideoCall = true
    static let enableTranslation = true
    static let enableDynamicIsland = true
    
    // Cache Settings
    static let maxCacheSize = 100 * 1024 * 1024 // 100MB
    static let messageCacheTimeout: TimeInterval = 24 * 60 * 60 // 24 hours
    
    // UI Constants
    enum UI {
        static let cornerRadius: CGFloat = 12
        static let padding: CGFloat = 16
        static let animationDuration: Double = 0.3
        
        static let colors = ThemeColors(
            primary: "007AFF",
            secondary: "5856D6",
            accent: "FF2D55",
            background: "F2F2F7",
            text: "000000"
        )
    }
}

struct ThemeColors {
    let primary: String
    let secondary: String
    let accent: String
    let background: String
    let text: String
}
