import Foundation
import FirebaseFirestore
import FirebaseAuth
import Combine

// MARK: - Data Models
struct CachedContact: Codable {
    let id: String
    let name: String
    let phone: String
    let email: String
    let lastMessage: String?
    let isOnline: Bool
    let lastSeen: Date?
    let cachedAt: Date
    
    init(from contact: Contact) {
        self.id = contact.id
        self.name = contact.name
        self.phone = contact.phone
        self.email = contact.email
        self.lastMessage = contact.lastMessage
        self.isOnline = contact.isOnline
        self.lastSeen = contact.lastSeen
        self.cachedAt = Date()
    }
    
    func toContact() -> Contact {
        var contact = Contact(name: name, phone: phone, email: email, lastMessage: lastMessage)
        contact.image = nil
        contact.imageURL = nil
        contact.lastSeen = lastSeen
        contact.isOnline = isOnline
        return contact
    }
}

struct CachedMessage: Codable {
    let id: String
    let senderId: String
    let receiverId: String
    let content: String
    let timestamp: Date
    let type: String
    let status: String
    let translation: String?
    let isEncrypted: Bool
    let cachedAt: Date
    
    init(from message: Message) {
        self.id = message.id
        self.senderId = message.senderId
        self.receiverId = message.receiverId
        self.content = message.content
        self.timestamp = message.timestamp
        self.type = message.type.rawValue
        self.status = message.status.rawValue
        self.translation = message.translation
        self.isEncrypted = message.isEncrypted
        self.cachedAt = Date()
    }
    
    func toMessage() -> Message {
        var message = Message(
            id: id,
            senderId: senderId,
            receiverId: receiverId,
            content: content,
            type: Message.MessageType(rawValue: type) ?? .text,
            attachments: nil,
            timestamp: timestamp,
            status: Message.MessageStatus(rawValue: status) ?? .sent,
            isEncrypted: isEncrypted
        )
        message.translation = translation
        return message
    }
}

struct CachedCall: Codable {
    let id: String
    let callerId: String
    let receiverId: String
    let startTime: Date
    let endTime: Date?
    let duration: TimeInterval
    let isVideo: Bool
    let status: String
    let cachedAt: Date
    
    init(id: String, callerId: String, receiverId: String, startTime: Date, endTime: Date? = nil, duration: TimeInterval, isVideo: Bool, status: String) {
        self.id = id
        self.callerId = callerId
        self.receiverId = receiverId
        self.startTime = startTime
        self.endTime = endTime
        self.duration = duration
        self.isVideo = isVideo
        self.status = status
        self.cachedAt = Date()
    }
}

struct CachedTranslation: Codable {
    let id: String
    let originalText: String
    let translatedText: String
    let sourceLanguage: String
    let targetLanguage: String
    let timestamp: Date
    let cachedAt: Date
    
    init(id: String, originalText: String, translatedText: String, sourceLanguage: String, targetLanguage: String, timestamp: Date) {
        self.id = id
        self.originalText = originalText
        self.translatedText = translatedText
        self.sourceLanguage = sourceLanguage
        self.targetLanguage = targetLanguage
        self.timestamp = timestamp
        self.cachedAt = Date()
    }
}

// MARK: - Data Persistence Manager
class DataPersistenceManager: ObservableObject {
    static let shared = DataPersistenceManager()
    
    private let userDefaults = UserDefaults.standard
    private let db = Firestore.firestore()
    private var cancellables = Set<AnyCancellable>()
    
    // Cache keys
    private enum CacheKeys {
        static let contacts = "cached_contacts"
        static let messages = "cached_messages"
        static let calls = "cached_calls"
        static let translations = "cached_translations"
        static let lastSyncTime = "last_sync_time"
        static let offlineMode = "offline_mode"
    }
    
    // Cache expiration times (in seconds)
    private enum CacheExpiration {
        static let contacts: TimeInterval = 3600 // 1 hour
        static let messages: TimeInterval = 86400 // 24 hours
        static let calls: TimeInterval = 604800 // 7 days
        static let translations: TimeInterval = 2592000 // 30 days
    }
    
    @Published var isOfflineMode = false
    @Published var lastSyncTime: Date?
    @Published var syncInProgress = false
    
    private init() {
        loadOfflineMode()
        loadLastSyncTime()
        setupNetworkMonitoring()
    }
    
    // MARK: - Network Monitoring
    private func setupNetworkMonitoring() {
        // Monitor network connectivity using Reachability or other network monitoring
        // For now, we'll use a simple approach with URLSession monitoring
        // In a real app, you'd use a proper network monitoring library like ReachabilitySwift
    }
    
    // MARK: - Contacts Caching
    func cacheContacts(_ contacts: [Contact]) {
        let cachedContacts = contacts.map { CachedContact(from: $0) }
        
        do {
            let data = try JSONEncoder().encode(cachedContacts)
            userDefaults.set(data, forKey: CacheKeys.contacts)
            print("✅ Cached \(contacts.count) contacts")
        } catch {
            print("❌ Failed to cache contacts: \(error)")
        }
    }
    
    func getCachedContacts() -> [Contact] {
        guard let data = userDefaults.data(forKey: CacheKeys.contacts) else {
            return []
        }
        
        do {
            let cachedContacts = try JSONDecoder().decode([CachedContact].self, from: data)
            let validContacts = cachedContacts.filter { contact in
                Date().timeIntervalSince(contact.cachedAt) < CacheExpiration.contacts
            }
            
            // Remove expired contacts
            if validContacts.count != cachedContacts.count {
                cacheContacts(validContacts.map { $0.toContact() })
            }
            
            return validContacts.map { $0.toContact() }
        } catch {
            print("❌ Failed to load cached contacts: \(error)")
            return []
        }
    }
    
    // MARK: - Messages Caching
    func cacheMessages(_ messages: [Message], for contactId: String) {
        let cachedMessages = messages.map { CachedMessage(from: $0) }
        
        do {
            let data = try JSONEncoder().encode(cachedMessages)
            userDefaults.set(data, forKey: "\(CacheKeys.messages)_\(contactId)")
            print("✅ Cached \(messages.count) messages for contact \(contactId)")
        } catch {
            print("❌ Failed to cache messages: \(error)")
        }
    }
    
    func getCachedMessages(for contactId: String) -> [Message] {
        let key = "\(CacheKeys.messages)_\(contactId)"
        guard let data = userDefaults.data(forKey: key) else {
            return []
        }
        
        do {
            let cachedMessages = try JSONDecoder().decode([CachedMessage].self, from: data)
            let validMessages = cachedMessages.filter { message in
                Date().timeIntervalSince(message.cachedAt) < CacheExpiration.messages
            }
            
            // Remove expired messages
            if validMessages.count != cachedMessages.count {
                cacheMessages(validMessages.map { $0.toMessage() }, for: contactId)
            }
            
            return validMessages.map { $0.toMessage() }
        } catch {
            print("❌ Failed to load cached messages: \(error)")
            return []
        }
    }
    
    // MARK: - Calls Caching
    func cacheCall(_ call: CachedCall) {
        var cachedCalls = getCachedCalls()
        cachedCalls.append(call)
        
        // Keep only recent calls (last 100)
        if cachedCalls.count > 100 {
            cachedCalls = Array(cachedCalls.suffix(100))
        }
        
        do {
            let data = try JSONEncoder().encode(cachedCalls)
            userDefaults.set(data, forKey: CacheKeys.calls)
            print("✅ Cached call \(call.id)")
        } catch {
            print("❌ Failed to cache call: \(error)")
        }
    }
    
    func getCachedCalls() -> [CachedCall] {
        guard let data = userDefaults.data(forKey: CacheKeys.calls) else {
            return []
        }
        
        do {
            let cachedCalls = try JSONDecoder().decode([CachedCall].self, from: data)
            let validCalls = cachedCalls.filter { call in
                Date().timeIntervalSince(call.cachedAt) < CacheExpiration.calls
            }
            
            // Remove expired calls
            if validCalls.count != cachedCalls.count {
                do {
                    let data = try JSONEncoder().encode(validCalls)
                    userDefaults.set(data, forKey: CacheKeys.calls)
                } catch {
                    print("❌ Failed to update cached calls: \(error)")
                }
            }
            
            return validCalls.sorted { $0.startTime > $1.startTime }
        } catch {
            print("❌ Failed to load cached calls: \(error)")
            return []
        }
    }
    
    // MARK: - Translations Caching
    func cacheTranslation(_ translation: CachedTranslation) {
        var cachedTranslations = getCachedTranslations()
        cachedTranslations.append(translation)
        
        // Keep only recent translations (last 500)
        if cachedTranslations.count > 500 {
            cachedTranslations = Array(cachedTranslations.suffix(500))
        }
        
        do {
            let data = try JSONEncoder().encode(cachedTranslations)
            userDefaults.set(data, forKey: CacheKeys.translations)
            print("✅ Cached translation \(translation.id)")
        } catch {
            print("❌ Failed to cache translation: \(error)")
        }
    }
    
    func getCachedTranslations() -> [CachedTranslation] {
        guard let data = userDefaults.data(forKey: CacheKeys.translations) else {
            return []
        }
        
        do {
            let cachedTranslations = try JSONDecoder().decode([CachedTranslation].self, from: data)
            let validTranslations = cachedTranslations.filter { translation in
                Date().timeIntervalSince(translation.cachedAt) < CacheExpiration.translations
            }
            
            // Remove expired translations
            if validTranslations.count != cachedTranslations.count {
                do {
                    let data = try JSONEncoder().encode(validTranslations)
                    userDefaults.set(data, forKey: CacheKeys.translations)
                } catch {
                    print("❌ Failed to update cached translations: \(error)")
                }
            }
            
            return validTranslations.sorted { $0.timestamp > $1.timestamp }
        } catch {
            print("❌ Failed to load cached translations: \(error)")
            return []
        }
    }
    
    // MARK: - Sync Management
    func syncWithFirebase() async {
        guard !syncInProgress else { return }
        guard let currentUser = Auth.auth().currentUser else { return }
        
        syncInProgress = true
        
        do {
            // Sync contacts
            await syncContacts(currentUser.uid)
            
            // Sync messages
            await syncMessages(currentUser.uid)
            
            // Sync calls
            await syncCalls(currentUser.uid)
            
            // Update sync time
            lastSyncTime = Date()
            saveLastSyncTime()
            
            print("✅ Sync completed successfully")
        } catch {
            print("❌ Sync failed: \(error)")
        }
        
        syncInProgress = false
    }
    
    private func syncContacts(_ userId: String) async {
        do {
            let snapshot = try await db.collection("users")
                .document(userId)
                .collection("contacts")
                .getDocuments()
            
            let contacts = snapshot.documents.compactMap { doc in
                try? doc.data(as: Contact.self)
            }
            
            cacheContacts(contacts)
        } catch {
            print("❌ Failed to sync contacts: \(error)")
        }
    }
    
    private func syncMessages(_ userId: String) async {
        do {
            let snapshot = try await db.collection("users")
                .document(userId)
                .collection("messages")
                .getDocuments()
            
            let messages = snapshot.documents.compactMap { doc in
                try? doc.data(as: Message.self)
            }
            
            // Group messages by contact
            let groupedMessages = Dictionary(grouping: messages) { $0.receiverId }
            
            for (contactId, contactMessages) in groupedMessages {
                cacheMessages(contactMessages, for: contactId)
            }
        } catch {
            print("❌ Failed to sync messages: \(error)")
        }
    }
    
    private func syncCalls(_ userId: String) async {
        do {
            let snapshot = try await db.collection("users")
                .document(userId)
                .collection("calls")
                .getDocuments()
            
            let calls = snapshot.documents.compactMap { doc in
                let data = doc.data()
                return CachedCall(
                    id: doc.documentID,
                    callerId: data["callerId"] as? String ?? "",
                    receiverId: data["receiverId"] as? String ?? "",
                    startTime: (data["startTime"] as? Timestamp)?.dateValue() ?? Date(),
                    endTime: (data["endTime"] as? Timestamp)?.dateValue(),
                    duration: data["duration"] as? TimeInterval ?? 0,
                    isVideo: data["isVideo"] as? Bool ?? false,
                    status: data["status"] as? String ?? "completed"
                )
            }
            
            for call in calls {
                cacheCall(call)
            }
        } catch {
            print("❌ Failed to sync calls: \(error)")
        }
    }
    
    // MARK: - Offline Mode Management
    func enableOfflineMode() {
        isOfflineMode = true
        saveOfflineMode(true)
        print("📱 Offline mode enabled")
    }
    
    func disableOfflineMode() {
        isOfflineMode = false
        saveOfflineMode(false)
        print("🌐 Offline mode disabled")
    }
    
    private func saveOfflineMode(_ isOffline: Bool) {
        userDefaults.set(isOffline, forKey: CacheKeys.offlineMode)
    }
    
    private func loadOfflineMode() {
        isOfflineMode = userDefaults.bool(forKey: CacheKeys.offlineMode)
    }
    
    private func saveLastSyncTime() {
        if let syncTime = lastSyncTime {
            userDefaults.set(syncTime, forKey: CacheKeys.lastSyncTime)
        }
    }
    
    private func loadLastSyncTime() {
        lastSyncTime = userDefaults.object(forKey: CacheKeys.lastSyncTime) as? Date
    }
    
    // MARK: - Cache Management
    func clearAllCache() {
        userDefaults.removeObject(forKey: CacheKeys.contacts)
        userDefaults.removeObject(forKey: CacheKeys.messages)
        userDefaults.removeObject(forKey: CacheKeys.calls)
        userDefaults.removeObject(forKey: CacheKeys.translations)
        userDefaults.removeObject(forKey: CacheKeys.lastSyncTime)
        
        print("🗑️ All cache cleared")
    }
    
    func clearExpiredCache() {
        // This will be called automatically when loading cached data
        // But we can also call it manually for cleanup
        _ = getCachedContacts()
        _ = getCachedCalls()
        _ = getCachedTranslations()
        
        print("🧹 Expired cache cleared")
    }
    
    func getCacheSize() -> String {
        let contacts = getCachedContacts().count
        let calls = getCachedCalls().count
        let translations = getCachedTranslations().count
        
        return "Contacts: \(contacts), Calls: \(calls), Translations: \(translations)"
    }
    
    // MARK: - Background Sync
    func scheduleBackgroundSync() {
        // Schedule background sync when app becomes active
        NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task {
                await self?.syncWithFirebase()
            }
        }
    }
    
    // MARK: - Data Export/Import
    func exportUserData() -> Data? {
        let exportData = [
            "contacts": getCachedContacts(),
            "calls": getCachedCalls(),
            "translations": getCachedTranslations(),
            "exportDate": Date(),
            "version": "1.0"
        ] as [String : Any]
        
        do {
            return try JSONSerialization.data(withJSONObject: exportData, options: .prettyPrinted)
        } catch {
            print("❌ Failed to export user data: \(error)")
            return nil
        }
    }
    
    func importUserData(_ data: Data) -> Bool {
        do {
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                return false
            }
            
            // Import contacts
            if let contactsData = json["contacts"] as? [[String: Any]] {
                let contacts = contactsData.compactMap { dict in
                    Contact(
                        name: dict["name"] as? String ?? "",
                        phone: dict["phone"] as? String ?? "",
                        email: dict["email"] as? String ?? "",
                        lastMessage: dict["lastMessage"] as? String
                    )
                }
                cacheContacts(contacts)
            }
            
            // Import calls
            if let callsData = json["calls"] as? [[String: Any]] {
                let calls = callsData.compactMap { dict in
                    CachedCall(
                        id: dict["id"] as? String ?? UUID().uuidString,
                        callerId: dict["callerId"] as? String ?? "",
                        receiverId: dict["receiverId"] as? String ?? "",
                        startTime: dict["startTime"] as? Date ?? Date(),
                        endTime: dict["endTime"] as? Date,
                        duration: dict["duration"] as? TimeInterval ?? 0,
                        isVideo: dict["isVideo"] as? Bool ?? false,
                        status: dict["status"] as? String ?? "completed"
                    )
                }
                for call in calls {
                    cacheCall(call)
                }
            }
            
            print("✅ User data imported successfully")
            return true
        } catch {
            print("❌ Failed to import user data: \(error)")
            return false
        }
    }
}
