import Foundation
import FirebaseFirestore
import FirebaseAuth
import WebRTC

// MARK: - Firebase Signaling Service
class FirebaseSignalingService: ObservableObject {
    static let shared = FirebaseSignalingService()
    
    private let db = Firestore.firestore()
    private var callListeners: [String: ListenerRegistration] = [:]
    private var userListeners: [String: ListenerRegistration] = [:]
    
    weak var delegate: FirebaseSignalingDelegate?
    
    private init() {
        setupUserPresenceListener()
    }
    
    deinit {
        removeAllListeners()
    }
    
    // MARK: - Call Management
    
    func createCall(to targetUserId: String, isVideo: Bool) async throws -> String {
        guard let currentUserId = Auth.auth().currentUser?.uid else {
            throw SignalingError.userNotAuthenticated
        }
        
        let callId = UUID().uuidString
        let call = Call(
            id: callId,
            callerId: currentUserId,
            calleeId: targetUserId,
            isVideo: isVideo,
            status: .initiated,
            createdAt: Date(),
            participants: [currentUserId, targetUserId]
        )
        
        try await db.collection("calls").document(callId).setData(call.toDictionary())
        
        // Listen for call updates
        listenForCallUpdates(callId: callId)
        
        return callId
    }
    
    func answerCall(callId: String, isVideo: Bool) async throws {
        guard let currentUserId = Auth.auth().currentUser?.uid else {
            throw SignalingError.userNotAuthenticated
        }
        
        let callRef = db.collection("calls").document(callId)
        
        try await callRef.updateData([
            "status": CallStatus.answered.rawValue,
            "answeredAt": Date(),
            "isVideo": isVideo
        ])
        
        // Listen for call updates
        listenForCallUpdates(callId: callId)
    }
    
    func endCall(callId: String) async throws {
        let callRef = db.collection("calls").document(callId)
        
        try await callRef.updateData([
            "status": CallStatus.ended.rawValue,
            "endedAt": Date()
        ])
        
        // Remove listener
        callListeners[callId]?.remove()
        callListeners.removeValue(forKey: callId)
    }
    
    func rejectCall(callId: String) async throws {
        let callRef = db.collection("calls").document(callId)
        
        try await callRef.updateData([
            "status": CallStatus.rejected.rawValue,
            "rejectedAt": Date()
        ])
        
        // Remove listener
        callListeners[callId]?.remove()
        callListeners.removeValue(forKey: callId)
    }
    
    // MARK: - Signaling Messages
    
    func sendOffer(callId: String, offer: RTCSessionDescription) async throws {
        let message = SignalingMessage(
            id: UUID().uuidString,
            callId: callId,
            type: .offer,
            senderId: Auth.auth().currentUser?.uid ?? "",
            sdp: offer.sdp,
            timestamp: Date()
        )
        
        try await db.collection("calls").document(callId)
            .collection("messages").document(message.id)
            .setData(message.toDictionary())
    }
    
    func sendAnswer(callId: String, answer: RTCSessionDescription) async throws {
        let message = SignalingMessage(
            id: UUID().uuidString,
            callId: callId,
            type: .answer,
            senderId: Auth.auth().currentUser?.uid ?? "",
            sdp: answer.sdp,
            timestamp: Date()
        )
        
        try await db.collection("calls").document(callId)
            .collection("messages").document(message.id)
            .setData(message.toDictionary())
    }
    
    func sendIceCandidate(callId: String, candidate: RTCIceCandidate) async throws {
        let message = SignalingMessage(
            id: UUID().uuidString,
            callId: callId,
            type: .iceCandidate,
            senderId: Auth.auth().currentUser?.uid ?? "",
            candidate: candidate.sdp,
            sdpMLineIndex: candidate.sdpMLineIndex,
            sdpMid: candidate.sdpMid ?? "",
            timestamp: Date()
        )
        
        try await db.collection("calls").document(callId)
            .collection("messages").document(message.id)
            .setData(message.toDictionary())
    }
    
    // MARK: - Listeners
    
    private func listenForCallUpdates(callId: String) {
        let listener = db.collection("calls").document(callId)
            .addSnapshotListener { [weak self] documentSnapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    self.delegate?.firebaseSignaling(self, didReceiveError: error)
                    return
                }
                
                guard let document = documentSnapshot,
                      let data = document.data(),
                      let call = Call(from: data) else {
                    return
                }
                
                self.delegate?.firebaseSignaling(self, didReceiveCallUpdate: call)
            }
        
        callListeners[callId] = listener
    }
    
    func listenForSignalingMessages(callId: String) {
        let listener = db.collection("calls").document(callId)
            .collection("messages")
            .order(by: "timestamp", descending: false)
            .addSnapshotListener { [weak self] querySnapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    self.delegate?.firebaseSignaling(self, didReceiveError: error)
                    return
                }
                
                guard let documents = querySnapshot?.documents else { return }
                
                for document in documents {
                    guard let message = SignalingMessage(from: document.data()) else { continue }
                    
                    // Only process messages from other users
                    if message.senderId != Auth.auth().currentUser?.uid {
                        self.delegate?.firebaseSignaling(self, didReceiveSignalingMessage: message)
                    }
                }
            }
        
        callListeners["\(callId)_messages"] = listener
    }
    
    private func setupUserPresenceListener() {
        guard let currentUserId = Auth.auth().currentUser?.uid else { return }
        
        // Update user presence
        let userRef = db.collection("users").document(currentUserId)
        userRef.updateData([
            "isOnline": true,
            "lastSeen": Date()
        ])
        
        // Listen for incoming calls
        let listener = db.collection("calls")
            .whereField("calleeId", isEqualTo: currentUserId)
            .whereField("status", isEqualTo: CallStatus.initiated.rawValue)
            .addSnapshotListener { [weak self] querySnapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    self.delegate?.firebaseSignaling(self, didReceiveError: error)
                    return
                }
                
                guard let documents = querySnapshot?.documents else { return }
                
                for document in documents {
                    guard let call = Call(from: document.data()) else { continue }
                    self.delegate?.firebaseSignaling(self, didReceiveIncomingCall: call)
                }
            }
        
        userListeners["incoming_calls"] = listener
    }
    
    private func removeAllListeners() {
        callListeners.values.forEach { $0.remove() }
        callListeners.removeAll()
        
        userListeners.values.forEach { $0.remove() }
        userListeners.removeAll()
    }
    
    // MARK: - User Management
    
    func updateUserPresence(isOnline: Bool) async throws {
        guard let currentUserId = Auth.auth().currentUser?.uid else { return }
        
        let userRef = db.collection("users").document(currentUserId)
        try await userRef.updateData([
            "isOnline": isOnline,
            "lastSeen": Date()
        ])
    }
    
    func getUserPresence(userId: String) async throws -> UserPresence {
        let userRef = db.collection("users").document(userId)
        let document = try await userRef.getDocument()
        
        guard let data = document.data() else {
            throw SignalingError.callNotFound
        }
        
        return UserPresence(
            userId: userId,
            isOnline: data["isOnline"] as? Bool ?? false,
            lastSeen: (data["lastSeen"] as? Timestamp)?.dateValue() ?? Date()
        )
    }
}

// MARK: - Firebase Signaling Delegate (moved to end of file)

// MARK: - Data Models

struct Call: Codable {
    let id: String
    let callerId: String
    let calleeId: String
    let isVideo: Bool
    let status: CallStatus
    let createdAt: Date
    let participants: [String]
    var answeredAt: Date?
    var endedAt: Date?
    var rejectedAt: Date?
    
    init(id: String, callerId: String, calleeId: String, isVideo: Bool, status: CallStatus, createdAt: Date, participants: [String]) {
        self.id = id
        self.callerId = callerId
        self.calleeId = calleeId
        self.isVideo = isVideo
        self.status = status
        self.createdAt = createdAt
        self.participants = participants
    }
    
    init?(from data: [String: Any]) {
        guard let id = data["id"] as? String,
              let callerId = data["callerId"] as? String,
              let calleeId = data["calleeId"] as? String,
              let isVideo = data["isVideo"] as? Bool,
              let statusString = data["status"] as? String,
              let status = CallStatus(rawValue: statusString),
              let createdAt = (data["createdAt"] as? Timestamp)?.dateValue(),
              let participants = data["participants"] as? [String] else {
            return nil
        }
        
        self.id = id
        self.callerId = callerId
        self.calleeId = calleeId
        self.isVideo = isVideo
        self.status = status
        self.createdAt = createdAt
        self.participants = participants
        self.answeredAt = (data["answeredAt"] as? Timestamp)?.dateValue()
        self.endedAt = (data["endedAt"] as? Timestamp)?.dateValue()
        self.rejectedAt = (data["rejectedAt"] as? Timestamp)?.dateValue()
    }
    
    func toDictionary() -> [String: Any] {
        var dict: [String: Any] = [
            "id": id,
            "callerId": callerId,
            "calleeId": calleeId,
            "isVideo": isVideo,
            "status": status.rawValue,
            "createdAt": Timestamp(date: createdAt),
            "participants": participants
        ]
        
        if let answeredAt = answeredAt {
            dict["answeredAt"] = Timestamp(date: answeredAt)
        }
        if let endedAt = endedAt {
            dict["endedAt"] = Timestamp(date: endedAt)
        }
        if let rejectedAt = rejectedAt {
            dict["rejectedAt"] = Timestamp(date: rejectedAt)
        }
        
        return dict
    }
}

struct SignalingMessage: Codable {
    let id: String
    let callId: String
    let type: SignalingMessageType
    let senderId: String
    let sdp: String?
    let candidate: String?
    let sdpMLineIndex: Int32?
    let sdpMid: String?
    let timestamp: Date
    
    init(id: String, callId: String, type: SignalingMessageType, senderId: String, sdp: String? = nil, candidate: String? = nil, sdpMLineIndex: Int32? = nil, sdpMid: String? = nil, timestamp: Date) {
        self.id = id
        self.callId = callId
        self.type = type
        self.senderId = senderId
        self.sdp = sdp
        self.candidate = candidate
        self.sdpMLineIndex = sdpMLineIndex
        self.sdpMid = sdpMid
        self.timestamp = timestamp
    }
    
    init?(from data: [String: Any]) {
        guard let id = data["id"] as? String,
              let callId = data["callId"] as? String,
              let typeString = data["type"] as? String,
              let type = SignalingMessageType(rawValue: typeString),
              let senderId = data["senderId"] as? String,
              let timestamp = (data["timestamp"] as? Timestamp)?.dateValue() else {
            return nil
        }
        
        self.id = id
        self.callId = callId
        self.type = type
        self.senderId = senderId
        self.sdp = data["sdp"] as? String
        self.candidate = data["candidate"] as? String
        self.sdpMLineIndex = data["sdpMLineIndex"] as? Int32
        self.sdpMid = data["sdpMid"] as? String
        self.timestamp = timestamp
    }
    
    func toDictionary() -> [String: Any] {
        var dict: [String: Any] = [
            "id": id,
            "callId": callId,
            "type": type.rawValue,
            "senderId": senderId,
            "timestamp": Timestamp(date: timestamp)
        ]
        
        if let sdp = sdp {
            dict["sdp"] = sdp
        }
        if let candidate = candidate {
            dict["candidate"] = candidate
        }
        if let sdpMLineIndex = sdpMLineIndex {
            dict["sdpMLineIndex"] = sdpMLineIndex
        }
        if let sdpMid = sdpMid {
            dict["sdpMid"] = sdpMid
        }
        
        return dict
    }
}

struct UserPresence: Codable {
    let userId: String
    let isOnline: Bool
    let lastSeen: Date
}

enum CallStatus: String, Codable, CaseIterable {
    case initiated = "initiated"
    case ringing = "ringing"
    case answered = "answered"
    case ended = "ended"
    case rejected = "rejected"
    case missed = "missed"
}

enum SignalingMessageType: String, Codable, CaseIterable {
    case offer = "offer"
    case answer = "answer"
    case iceCandidate = "iceCandidate"
    case callEnd = "callEnd"
}

// Note: SignalingError is defined in SignalingClient.swift

// MARK: - Firebase Signaling Delegate
protocol FirebaseSignalingDelegate: AnyObject {
    func firebaseSignaling(_ service: FirebaseSignalingService, didReceiveCallUpdate call: Call)
    func firebaseSignaling(_ service: FirebaseSignalingService, didReceiveIncomingCall call: Call)
    func firebaseSignaling(_ service: FirebaseSignalingService, didReceiveSignalingMessage message: SignalingMessage)
    func firebaseSignaling(_ service: FirebaseSignalingService, didReceiveError error: Error)
}
