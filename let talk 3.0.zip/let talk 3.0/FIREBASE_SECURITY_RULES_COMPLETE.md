# Complete Firebase Security Rules for Let Talk 3.0

## Overview
This document provides the complete Firebase Firestore security rules needed to fix all permission issues in the Let Talk 3.0 app.

## Security Rules

Copy and paste these rules into your Firebase Console > Firestore Database > Rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function isOwner(userId) {
      return isAuthenticated() && request.auth.uid == userId;
    }
    
    function isOwnerOrParticipant(userId) {
      return isAuthenticated() && (
        request.auth.uid == userId || 
        resource.data.participants.hasAny([request.auth.uid])
      );
    }
    
    // Users collection
    match /users/{userId} {
      allow read, write: if isOwner(userId);
      
      // User's contacts subcollection
      match /contacts/{contactId} {
        allow read, write: if isOwner(userId);
      }
      
      // User's chats subcollection
      match /chats/{chatId} {
        allow read, write: if isOwner(userId);
      }
    }
    
    // Global contacts collection (for backward compatibility)
    match /contacts/{contactId} {
      allow read, write: if isAuthenticated();
    }
    
    // Messages collection
    match /messages/{messageId} {
      allow read, write: if isAuthenticated() && (
        request.auth.uid == resource.data.senderId ||
        request.auth.uid == resource.data.receiverId
      );
      allow create: if isAuthenticated() && (
        request.auth.uid == request.resource.data.senderId
      );
    }
    
    // Chats collection
    match /chats/{chatId} {
      allow read, write: if isAuthenticated() && (
        request.auth.uid in resource.data.participants
      );
      allow create: if isAuthenticated() && (
        request.auth.uid in request.resource.data.participants
      );
    }
    
    // Calls collection
    match /calls/{callId} {
      allow read, write: if isAuthenticated() && (
        request.auth.uid == resource.data.callerId ||
        request.auth.uid == resource.data.calleeId
      );
      allow create: if isAuthenticated() && (
        request.auth.uid == request.resource.data.callerId
      );
      
      // Call signaling subcollection
      match /signaling/{signalingId} {
        allow read, write: if isAuthenticated() && (
          request.auth.uid == get(/databases/$(database)/documents/calls/$(callId)).data.callerId ||
          request.auth.uid == get(/databases/$(database)/documents/calls/$(callId)).data.calleeId
        );
      }
      
      // Call participants subcollection
      match /participants/{participantId} {
        allow read, write: if isAuthenticated() && (
          request.auth.uid == get(/databases/$(database)/documents/calls/$(callId)).data.callerId ||
          request.auth.uid == get(/databases/$(database)/documents/calls/$(callId)).data.calleeId
        );
      }
    }
    
    // User presence collection
    match /presence/{userId} {
      allow read, write: if isOwner(userId);
    }
    
    // App settings collection
    match /settings/{settingId} {
      allow read: if isAuthenticated();
      allow write: if isAuthenticated() && request.auth.uid == resource.data.userId;
    }
    
    // Notifications collection
    match /notifications/{notificationId} {
      allow read, write: if isAuthenticated() && (
        request.auth.uid == resource.data.userId
      );
      allow create: if isAuthenticated() && (
        request.auth.uid == request.resource.data.userId
      );
    }
    
    // Translation history collection
    match /translations/{translationId} {
      allow read, write: if isAuthenticated() && (
        request.auth.uid == resource.data.userId
      );
      allow create: if isAuthenticated() && (
        request.auth.uid == request.resource.data.userId
      );
    }
    
    // Call history collection
    match /callHistory/{callHistoryId} {
      allow read, write: if isAuthenticated() && (
        request.auth.uid == resource.data.userId
      );
      allow create: if isAuthenticated() && (
        request.auth.uid == request.resource.data.userId
      );
    }
  }
}
```

## Implementation Steps

1. **Open Firebase Console**
   - Go to [Firebase Console](https://console.firebase.google.com)
   - Select your project

2. **Navigate to Firestore Rules**
   - Click on "Firestore Database" in the left sidebar
   - Click on the "Rules" tab

3. **Replace Existing Rules**
   - Delete all existing rules
   - Copy and paste the rules above
   - Click "Publish"

4. **Test the Rules**
   - The rules will be active immediately
   - Test your app to ensure contacts can be saved and calls work

## Key Features of These Rules

### ✅ **User Authentication**
- All operations require authentication
- Users can only access their own data

### ✅ **Contact Management**
- Users can read/write their own contacts
- Contacts are stored in user-specific subcollections
- Backward compatibility with global contacts collection

### ✅ **Call Functionality**
- Users can create calls as callers
- Users can read/write calls they're involved in
- Signaling and participant data is properly secured

### ✅ **Message Security**
- Users can only access messages they sent or received
- Message creation requires sender authentication

### ✅ **Chat Management**
- Users can only access chats they participate in
- Chat creation requires participant authentication

### ✅ **Data Privacy**
- All user data is isolated by user ID
- No cross-user data access allowed

## Troubleshooting

If you still get permission errors:

1. **Check Authentication Status**
   ```swift
   print("User authenticated: \(Auth.auth().currentUser != nil)")
   print("User ID: \(Auth.auth().currentUser?.uid ?? "nil")")
   ```

2. **Verify User Document Exists**
   - Ensure user documents are created in the `users` collection
   - Check that the document ID matches the user's UID

3. **Check Field Names**
   - Ensure your app uses the correct field names (e.g., `callerId`, `calleeId`)
   - Verify that user IDs are stored correctly

4. **Test with Firebase Rules Simulator**
   - Use the Firebase Console Rules Simulator to test specific operations
   - This helps identify which rules are blocking operations

## Additional Security Considerations

1. **Enable App Check** (Recommended)
   - Go to Firebase Console > App Check
   - Enable App Check for your app
   - This prevents abuse from unauthorized clients

2. **Monitor Usage**
   - Check Firebase Console > Usage tab
   - Monitor for unusual activity

3. **Regular Security Reviews**
   - Review these rules periodically
   - Update as your app evolves

## Support

If you continue to experience issues:

1. Check the Firebase Console logs for specific error messages
2. Verify your app is using the correct Firebase project
3. Ensure all required fields are present in your documents
4. Test with a simple read/write operation first

These rules should resolve all the "Permission denied" errors you were experiencing with contacts and calls.
